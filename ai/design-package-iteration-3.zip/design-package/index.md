# Design Package

Run ID: gitcode-mcp-live-readiness-design-agent-20260621T160404Z-gitcode_mcp_live_readiness_iteration_3

## Documents
- [Clarified Task](clarified-task.md)
- [Outcome Contract](outcome-contract.md)
- [Decommission Ledger](decommission-ledger.md)
- [Research Results](research-results.md)
- [Architecture](architecture.md)
- [Implementation Tasks](implementation-tasks.md)
- [Component Plans](components/index.md)

## Exported Components
- [CLI Entrypoint](components/cmd-gitcode-mcp.md) (`cmd-gitcode-mcp`)
- [Service Factory](components/internal-service.md) (`internal-service`)
- [Provider Interface and Dispatch](components/internal-provider.md) (`internal-provider`)
- [Live GitCode Adapter](components/internal-provider-live.md) (`internal-provider-live`)
- [Credential Pipeline](components/internal-credential.md) (`internal-credential`)
- [Cache Storage](components/internal-cache.md) (`internal-cache`)
- [Sync Engine](components/internal-sync.md) (`internal-sync`)
- [Index Engine](components/internal-index.md) (`internal-index`)
- [Search Engine](components/internal-search.md) (`internal-search`)
- [Audit Trail](components/internal-audit.md) (`internal-audit`)
- [Redaction Filter](components/internal-diagnostics.md) (`internal-diagnostics`)
- [Doctor Aggregator](components/internal-doctor.md) (`internal-doctor`)
- [MCP Server](components/internal-mcp.md) (`internal-mcp`)
- [MCP Tool Schemas](components/internal-mcp-tools.md) (`internal-mcp-tools`)
- [MCP Transport Layer](components/internal-mcp-transport.md) (`internal-mcp-transport`)
- [E2E Test Harness](components/internal-e2e.md) (`internal-e2e`)
- [Documentation](components/docs.md) (`docs`)


## Component Summary
- Planned components: 17
- Approved component reviews: 3/17
- Components needing changes: 14
