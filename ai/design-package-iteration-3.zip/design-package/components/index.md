# Component Designs

This file is component navigation only. Use [Implementation Tasks](../implementation-tasks.md) for execution order.

- [CLI Entrypoint](cmd-gitcode-mcp.md) (`cmd-gitcode-mcp`)
- [Service Factory](internal-service.md) (`internal-service`)
- [Provider Interface and Dispatch](internal-provider.md) (`internal-provider`)
- [Live GitCode Adapter](internal-provider-live.md) (`internal-provider-live`)
- [Credential Pipeline](internal-credential.md) (`internal-credential`)
- [Cache Storage](internal-cache.md) (`internal-cache`)
- [Sync Engine](internal-sync.md) (`internal-sync`)
- [Index Engine](internal-index.md) (`internal-index`)
- [Search Engine](internal-search.md) (`internal-search`)
- [Audit Trail](internal-audit.md) (`internal-audit`)
- [Redaction Filter](internal-diagnostics.md) (`internal-diagnostics`)
- [Doctor Aggregator](internal-doctor.md) (`internal-doctor`)
- [MCP Server](internal-mcp.md) (`internal-mcp`)
- [MCP Tool Schemas](internal-mcp-tools.md) (`internal-mcp-tools`)
- [MCP Transport Layer](internal-mcp-transport.md) (`internal-mcp-transport`)
- [E2E Test Harness](internal-e2e.md) (`internal-e2e`)
- [Documentation](docs.md) (`docs`)
