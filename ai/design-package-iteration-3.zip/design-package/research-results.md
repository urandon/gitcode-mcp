# Research Results

## Research Index
# Research Index

## Competitor Research
- Model Context Protocol: `source document`
- GitHub CLI: `source document`
- Git Credential Manager: `source document`
- go-keyring: `source document`
- 99designs keyring: `source document`

## External Research

## Competitor Analysis

### Reference Study: GitHub CLI

GitHub CLI implements a three-layer token acquisition pipeline (env var → config file → OS keyring) with explicit source labeling and prefix-aware redaction used by `auth status` to inform operators exactly where their credentials live without exposing secrets. Its command registration uses a custom help function that groups subcommands by category, surfaces help topics, and provides context-aware auth guidance in CI and interactive modes. Live write operations are gated by a `--dry-run` flag that renders the full payload without API calls and an interactive confirmation prompt (Submit/Submit as Draft/PMetadata/Cancel) before any real mutation.

### Reference Study: Git Credential Manager

Git Credential Manager implements credential-store UX through a lazy credential-store dispatcher, platform-specific secure-store backends, and a `diagnose` command that verifies storage and environment health.
The key architectural choice is to centralize store selection around configured/default store names, then validate platform/session prerequisites before constructing a concrete backend.
The strongest transferable idea is a public-safe `auth status`/`doctor` flow that reports token source and credential-store readiness without printing token material, backed by explicit redaction APIs.

### Reference Study: go-keyring

go-keyring provides an OS-agnostic Get/Set/Delete/DeleteAll/ListUsers interface for system keyring secrets across macOS (security CLI), Linux/BSD (D-Bus Secret Service), and Windows (wincred API), selecting the platform provider at init time via build-tag-constrained Go source files. Its key architectural choice is using a package-level `provider` variable mutated by per-OS `init()` functions, with zero CGo dependencies even on macOS (it shells out to `/usr/bin/security` instead). The strongest transferable idea for gitcode-mcp is the mock-init/restore pattern for test isolation combined with the platform-gated init-selection model, which allows a macOS Keychain credential provider to exist as an optional component without hard compile-time dependencies for other platforms.

### Reference Study: 99designs keyring

99designs/keyring provides a unified `Keyring` interface over seven backend credential stores (macOS Keychain, Windows Credential Manager, Secret Service, KWallet, kernel keyctl, pass, encrypted file) with a priority-ordered `Open()` dispatcher that auto-selects the best available backend while allowing callers to constrain `AllowedBackends`.
The key architectural choice is the `supportedBackends` map + `backendOrder` slice pattern: each OS-specific backend registers an `opener` function via package `init()`, guarded by build tags and runtime preflight checks, so registration and backend selection are both compile-time-and-runtime-gated and never panic on unsupported platforms.
The strongest transferable idea for GitCode MCP credential handling is the three-layer gate pattern — build tags filter compilation, `init()` performs lightweight availability probes (e.g., D-Bus session check) and conditionally registers the opener, and `Open()` iterates a priority-ordered list with fallback — which maps directly to the need for an env-token baseline with optional macOS Keychain fallback and future Linux/Windows expansion.

### Reference Study: Model Context Protocol

The MCP specification defines JSON-RPC tool schemas with JSON Schema 2020-12 enumerated types via `enum: string[]` or `oneOf` with `const`/`title` pairs, registers tools through `tools/list` responses with deterministic ordering and `listChanged` notifications, and provides transport health verification through `server/discover` (not ping — ping was removed in draft 2026-07-28). The key architectural choice is per-request protocol version negotiation via `_meta` fields rather than a global handshake, with discriminated union types (`resultType: "complete" | "input_required"`) serving as the primary kind discriminator for responses. The strongest transferable idea for the subject system is using `server/discover` as the transport-health probe for the `doctor` command and adopting `TitledSingleSelectEnumSchema`-style `oneOf` + `const`/`title` for the MCP tool kind enum declarations.

## External Research

# External Research Synthesis: GitCode MCP Live-Readiness Iteration 3

## Executive Summary

The gitcode-mcp codebase implements a cache-first GitCode CLI/MCP tool with fixture-backed testing, repository scoping, sync/index pipeline, MCP read tools over stdio and HTTP/SSE transport, and a write engine with idempotency and audit trail — all proven through iteration 2. However, every live-path operation is blocked by a single architectural gap: the `defaultServiceFactory` and MCP serve paths hardcode `service.New(store)`, which embeds a read-only `sanitizedFixtureClient` that returns deterministic fixture data (ISSUE-42, WIKI-HOME) and rejects all writes. A `NewLiveProvider(cfg)` constructor, a fully-defined `Provider` interface, and a `service.NewWithClient(store, client)` injection path all exist but are never wired at runtime. The iteration 3 "live-readiness" work is therefore primarily a wiring and validation exercise — bridging the existing live provider and credential pipeline into the CLI and MCP dispatch paths, then fixing accumulated enumeration/help/search freshness defects that prevent operators from reaching the live data they already have the code to produce.

## Research Scope And Source Strategy

No external web sources were retrieved. All evidence comes from direct source code inspection of the target repository at `/Users/urandon/workspace/ai-processing/gitcode-mcp`, covering ~5,800 lines across 7 core files plus config, index, and docs. The analysis maps every existing mechanism against the 13 formalized tasks to identify what already exists, what needs wiring, and what must be created from scratch.

## Relevant Existing External Mechanisms

### Provider Selection and Factory Wiring (ext1)
- **`gitcode.NewLiveProvider(cfg)`** (`internal/gitcode/provider.go:95-104`): Creates a live HTTP-backed provider when `cfg.Mode == live`, `cfg.LiveAllowed == true`, and token is non-empty. Returns `ErrProviderUnavailable` otherwise.
- **`service.NewWithClient(store, client)`** (`internal/service/service.go:34-38`): Exists as the test-injection constructor. Calls `New(store)` then overwrites `svc.client` with the supplied client.
- **`RequireLiveProviderForTest()`** (`internal/gitcode/provider.go:110-119`): Guards on `GITCODE_LIVE_TEST=1` and `GITCODE_LIVE_TOKEN`/`GITCODE_TEST_TOKEN`. Returns `(token, true)` for test opt-in.
- **Three `ProviderMode` constants**: `live`, `fixture`, `unavailable`. `NewUnavailableProvider(reason)` wraps all methods in `ErrProviderUnavailable`.
- **Blocking gap**: `defaultServiceFactory` at `internal/cli/cli.go:190` unconditionally calls `service.New(store)`. MCP stdio path at `cmd/gitcode-mcp/main.go:309` and HTTP/SSE path at `cmd/gitcode-mcp/main.go:328` both use `service.New(store)`. The `--live` CLI flag is parsed but never consumed for provider switching.

### Credential Handling Pipeline (ext2)
- **`EnvCredentialProvider`** (`internal/config/effective.go:69-84`): Reads `GITCODE_TOKEN` env var. Returns `missingCredentialStatus` with source `"missing"`, `ErrorClass: "token-missing"`, `Remediation: "Set GITCODE_TOKEN or configure a credential store."`.
- **`ChainCredentialProvider`** (`internal/config/effective.go:127-160`): Iterates providers. Default chain contains only `EnvCredentialProvider`. `Status()` returns first present provider's result or last status.
- **`StaticCredentialProvider`** (`internal/config/effective.go:91-125`): Designed for test injection and Keychain-like backends. Stores source, token, StoreMode, ErrorClass, Remediation. Source defaults to `"keyring"` when token present and no explicit source.
- **`CredentialStatus`** struct: `Source, Present, StoreMode, ErrorClass, Remediation`. All fields redactable.
- **`config.RedactDiagnostic`**: Replaces token values and config file paths with `[REDACTED]`.
- **`auth status` CLI** (`internal/cli/cli.go:361-372`): Calls `deps.CredentialReporter.Status()` and renders `CredentialStatus`.
- **No `go-keyring` or `99designs/keyring`** in `go.mod` (ext8). No Keychain provider implementation exists. `StaticCredentialProvider` is defined but never wired to a real Keychain backend.

### Live Sync Pipeline (ext3)
- **`SyncToCache`** (`internal/service/service.go:753-839`): Full sync pipeline with idempotency key derivation (SHA256 of sync params), writer lock acquisition, integrity check, `fetchAndStage` with retry, `stageIssue`/`stageWiki` content hash deduplication, `UpsertSyncGraph`, WAL checkpoint, and sync event tracking (in_progress → succeeded/failed).
- **Error normalization**: Maps `ErrAuthExpired` → `auth_expired`, `ErrConflict` → `conflict`, `ErrRemoteNotFound` → `remote_not_found`, `ErrPartialResponse` → `partial_response`, `ErrRateLimited` → `rate_limited` with `RetryAfter`.
- **`fetchOnce`** (`internal/service/service.go:1061-1082`): Dispatches `issue` → `GetIssue` + `stageIssue`, `wiki/page/remote` → `GetWikiPage` + `stageWiki`.
- **`stageIssue`** computes SHA256 of `title+body+state+labels` → `ContentHash`. Compares against existing source to determine `Skipped`/`Updated`/`Inserted`. Fetches comments via `ListIssueComments`.
- **`stageWiki`** builds `SourceGraph` with `Kind: "wiki"`, path `wiki/{id}.md`, version tracking.
- **Pagination types**: `Page[T]` with `Items, Page, PerPage, TotalCount, NextPage` at `internal/gitcode/models.go:52-58`.
- **Gap**: `SyncRequest` handles single remote aliases only. No batch `ListIssues`/`ListWikiPages` iteration for full-repo sync. CLI `--issues` hardcodes `remote_alias="issue:42"`, `--wiki` hardcodes `"wiki:Home"`.

### Live Write Engine with Idempotency and Audit Trail (ext4)
- **`executeWrite`** (`internal/service/service.go:1400-1475`): Three-phase execution: adapter call → audit record → cache refresh. Validates `--dry-run` or `--live` exclusivity. Dry-run builds route, computes idempotency key, returns `{Status:"dry_run_valid"}` without adapter call.
- **Idempotency key**: `writeIdempotency` serializes `(command, repoID, id, number, slug, title, body, state, labels)` as JSON → SHA256. Explicit `--idempotency-key` overrides.
- **Replay**: `GetAuditEventByKey` checks audit_trail. Four cases: payload mismatch → `write_idempotency_conflict`; succeeded → replay; `remote_confirmed_cache_refresh_failed` → replay cache refresh; `remote_confirmed_audit_failed` → error.
- **Operations**: `CreateIssue`, `UpdateIssue`, `CreatePage`, `UpdatePage`, `AddComment` all implemented. `AddLabel` returns deferred error immediately (stub).
- **`callWriteAdapter`** dispatches to `client.CreateIssue`, `client.UpdateIssue`, `client.CreateIssueComment`, `client.CreateWikiPage`, `client.UpdateWikiPage` with `WriteOptions{IdempotencyKey}`.
- **`WriteCommandResult`** includes `remote_id`, `remote_number`, `remote_slug`, `remote_revision`, `idempotency_key`, `source_fingerprint`, `replayed`, `evidence`.
- **Gap**: Entirely inoperative because the default client is `sanitizedFixtureClient` which returns `ErrInvalidQuery{Field:"write", Message:"fixture client is read-only"}` for all writes. Write credential guard at line 1419 checks `os.Getenv("GITCODE_TOKEN")` directly (bypassing the credential provider chain).

### Cache Schema Migration (ext5)
- **`schema_version` table** with single INTEGER column. `currentSchemaVersion = 4` (`internal/cache/schema.go:9`).
- **Four migrations**: v1 (initial), v2 (repo-scoped records/comments/audit/snapshots), v3 (chunk_policy columns), v4 (stored_snapshot metadata).
- **`runMigrations`** (`internal/cache/schema.go:23-60`): Auto-runs on store open. Forward-only. Detects existing columns via `PRAGMA table_info`. Each migration in a dedicated transaction. Version updated by DELETE then INSERT.
- **Future-version safeguard**: Returns `"cache: schema version X is newer than supported version Y"`.
- **FTS5 detection**: Probes via `CREATE VIRTUAL TABLE temp.fts5_probe USING fts5(value)`.
- **Writer lock** acquired with `operation:"migration"` before migrations.
- **Gap**: No explicit `migrate-cache` CLI command. No dry-run mode. No backup before migration. Error message lacks remediation steps.

### Index Freshness and Stale-Index Detection (ext6)
- **`BuildFreshnessReport`** (`internal/index/stale.go:71-176`): Compares source content hash against indexed chunk ContentHash. Triggers `WarningStaleIndex` only when `currentHash != "" && state.ContentHash != "" && currentHash != state.ContentHash`.
- **Freshness key**: `repoID\x00sourceID\x00recordID\x00snapshotID\x00policy` — ensures correct per-policy matching.
- **`indexed_at`** stored in chunk `InheritedMetadata["indexed_at"]` parsed via `time.RFC3339Nano`.
- **`indexSourceRecord`** sets `Metadata["content_hash"] = source.ContentHash` and `Metadata["source_updated_at"] = source.UpdatedAt`.
- **Separate link staleness**: `IndexFreshnessLinkStaleOnly`/`WarningLinkStaleOnly` for derived link staleness independent of content freshness.
- **Gap**: `indexed_at` is not a dedicated column — relies on metadata propagation through `InheritedMetadata`. If metadata is lost during indexing, false positives occur. `sync --index` flag exists but sync command does not chain index after sync.

### MCP Tool System (ext7)
- **15 registered MCP tools** (`internal/mcp/mcp.go:198-351`): `search_sources`, `get_source`, `list_sources`, `list_chunks`, `search_chunks`, `get_snippet`, `stale_index_report`, `recent_changes`, `link_check`, `cache_status`, `source_backlinks`, `resolve_id`, `sync_status`, `export_snapshot`, `diff_snapshot`.
- **Dual transport**: stdio (`Server.Serve()` reads JSON-RPC from stdin) and HTTP/SSE (`NewHTTPSSETransport` with `ReadinessProbe`).
- **Structured content**: Each tool returns both `Content: [{Type:"text", Text}]` and `StructuredContent` (JSON object).
- **`validKind()`** at line 778: Accepts only `["source","task","page","decision","handoff"]`. Misses `"issue"` and `"wiki"`.
- **Kind enum arrays in 3 toolDefs**: `search_sources`, `list_sources`, `recent_changes` all use the incomplete legacy enum.
- **Gap**: MCP always uses `service.New(store)` with fixture provider. No path to live-synced data.

### CLI Command and Help Architecture (ext9)
- **`commands` slice** (`internal/cli/cli.go:23-50`): Lists all valid subcommands including `doctor`, `auth`, `config`, `repo`.
- **`printHelp`** (`internal/cli/cli.go:964-1006`): Flat command list, shell-equivalent mappings, global flags, global options. No per-command help text.
- **`isKnownCommand`**: Case-insensitive match. Unknown commands trigger help.
- **Gap**: Per-command `--help` (e.g., `gitcode-mcp sync --help`) not implemented. Flag package's `ContinueOnError` discards help requests. `doctor` without `--runtime-audit` returns `"subcommand is required"` error. `auth` without subcommand same.

### Doctor/Runtime-Audit Command (ext10)
- **`BuildRuntimeAuditConfigReport`** (`internal/config/runtime_audit.go:34-87`): Aggregates version, config path/source/format/exists, cache path/source, credential source/present/mode, failure_classes, remediation, handoff_fields. All credential strings redacted.
- **`doctor` CLI** (`internal/cli/cli.go:314-323`): Requires `--runtime-audit` flag. Without it, returns `"subcommand is required"`. Reports only config/credential info.
- **MCP `ReadinessProbe`** (`cmd/gitcode-mcp/main.go:329-342`): Checks `store.ListRepositories`. Returns `Ready:true` if repos exist, `"cache_unreadable"` on store error, `"repo_unavailable"` when no repos.
- **Gap**: Doctor does not open cache store, inspect schema version, query last sync event, run freshness report, or report MCP transport health. No default mode without `--runtime-audit`.

## Design-Critical Unknowns

1. **GitCode API conditional-write support**: The adapter interface supports `ErrConflict` but no `If-Match`/`ETag` precondition check exists. Unknown whether the GitCode API supports conditional writes. If it does not, conflict detection is purely post-hoc (write fails after concurrent modification is detected server-side), and the design cannot guarantee lost-update prevention.

2. **GitCode API label CRUD**: `AddLabel`/`RemoveLabel` exist as adapter stubs. Unknown whether the GitCode API supports label management via REST. If it does not, label operations must be excluded from iteration 3 scope.

3. **GitCode API wiki pagination granularity**: `ListWikiPages` exists in the adapter but pagination behavior (page size limits, total count accuracy) is untested against the live API. Unknown whether wiki pages can be listed in bulk for full-repo sync.

4. **Rate-limit header format**: `normalizeSyncFailure` maps `ErrRateLimited` with `RetryAfter` but the actual rate-limit header parsing is untested against the live API. Unknown whether the API returns `Retry-After` seconds or a timestamp.

5. **`indexed_at` metadata propagation root cause**: The false `stale_index` warnings observed in iteration 2 may stem from metadata loss during the indexing pipeline or from incorrect `indexed_at` time comparison. The exact failure point in `InheritedMetadata` propagation is not diagnosed from code inspection alone.

6. **SQLite WAL checkpointing behavior under the migration lock**: If a migration fails mid-flight, the writer lock must be released. The current design acquires the lock via `store.AcquireWriter` but failure cleanup is untested for migration-scoped locks.

## Architecture Alternatives And Trade-Offs

### Provider Selection: Factory Injection vs. Global Mode Flag

| Approach | Mechanism | Trade-Off |
|----------|-----------|-----------|
| **Factory injection (recommended)** | Extend `defaultServiceFactory` to accept deps, build live client when `--live` flag set, pass via `NewWithClient` | Narrow change surface; leverages existing `NewWithClient`; MCP paths need separate injection |
| Global mode flag | Set a package-level `var LiveMode bool` checked in `New()` | Simpler dispatch; pollutes global state; breaks concurrent test determinism |
| Config-driven provider | Read `config.ProviderMode` from effective config | Decouples CLI from provider selection; adds config schema dependency for runtime behavior |

**Recommendation**: Factory injection using `NewWithClient`. The injection path already exists and is tested in `service_test.go`. The config-driven approach is viable for iteration 4 but adds unnecessary config surface for iteration 3.

### Keychain Integration: go-keyring vs. 99designs/keyring vs. osascript

| Library | Import Footprint | Platform Support | Maturity |
|---------|-----------------|------------------|----------|
| `github.com/zalando/go-keyring` | ~10 transitive deps | macOS, Linux (dbus), Windows | 1.8k stars, widely used |
| `github.com/99designs/keyring` | ~25 transitive deps | macOS, Linux, Windows, K8s | 1.5k stars, plugin-based |
| Raw `osascript` via `os/exec` | 0 deps | macOS only | Brittle, no structured output |

**Recommendation**: `zalando/go-keyring` for minimal dependency footprint. `99designs/keyring` offers more backends but adds ~15 unnecessary transitive dependencies for a macOS-only optional feature. The `StaticCredentialProvider` already defines the interface surface for either.

### Sync Model: Individual vs. Bulk vs. Discover-and-Sync

| Approach | Mechanism | Trade-Off |
|----------|-----------|-----------|
| **Discover-and-sync (recommended for full-repo)** | Call `ListIssues`/`ListWikiPages` to enumerate, then `SyncToCache` per item | Reuses existing single-item sync pipeline; provides per-item idempotency and failure isolation |
| Bulk sync | New `SyncAllToCache` method that fetches and stages all items in one transaction | Atomic per repo; recovery from partial failure is complex; all-or-nothing semantics |
| Individual sync (current) | Operator specifies each remote alias | Simple; not scalable for repos with many items |

**Recommendation**: Discover-and-sync. The existing `SyncToCache` pipeline (with idempotency, retry, audit events, content hash deduplication, and error normalization) is proven. Bulk sync introduces atomicity challenges that are premature for iteration 3.

## Primary Decision Hierarchy

1. **Provider selection wiring** (`--live` → `NewLiveProvider` → `NewWithClient`) is the **single blocking dependency** for Tasks 3, 4, 5, 12. Everything else is parallelizable once the factory injects a live client.

2. **Credential pipeline** is **already functional** for env tokens. Keychain is additive and non-blocking. `auth status` preflight probing (calling `ProbeAuth` against live API) is the highest-value credential improvement.

3. **Kind enum fix** (`validKind` + 3 toolDef arrays) is **isolated to one file** (`internal/mcp/mcp.go`) and unblocks MCP `search_sources` (Task 7) and MCP schema correctness (Task 8).

4. **Stale-index fix** depends on diagnosing the `indexed_at` metadata propagation path. The hash comparison logic itself is sound. Fix may be in `indexSourceRecord` metadata assignment or in `BuildFreshnessReport` comparison.

5. **Full-repo sync** is a new feature (not a fix). Depends on provider selection (Decision 1). Uses existing single-item sync pipeline iteratively.

6. **Two-cache e2e harness** is net-new creation. Depends on provider selection (Decision 1) and full-repo sync (Decision 5). Gated by `//go:build e2e` tag.

7. **Doctor/readiness command** extension is additive to existing `RuntimeAuditConfigReport`. Requires opening the cache store, querying schema version, counting sources, finding last sync event, running freshness report, and probing MCP readiness.

8. **Per-command help** is surface-level CLI fix. Either a `--help` flag handler in `parseOptions` or a `help <subcommand>` meta-command.

9. **Cache migration command** is operator-facing visibility. The migration engine runs automatically; the command adds dry-run, preview, and remediation text.

10. **Documentation updates** are parallel to all code changes and can proceed independently.

## Low-Level Implementation Details

### Provider Selection Injection Points

```
// Current (blocking):
defaultServiceFactory → service.New(store) → sanitizedFixtureClient

// Required:
// CLI path:
defaultServiceFactory(ctx, cachePath, deps) → 
  if --live: NewLiveProvider(cfg) → NewWithClient(store, liveClient)
  else: service.New(store)

// MCP stdio path (cmd/gitcode-mcp/main.go:309):
// Replace: service.New(store)
// With: if deps.liveMode { service.NewWithClient(store, liveClient) } else { service.New(store) }

// MCP HTTP/SSE path (cmd/gitcode-mcp/main.go:328):
// Same pattern
```

### Kind Enum Fix Target

```
// internal/mcp/mcp.go:778-785 — validKind()
// Change: ["source","task","page","decision","handoff"]
// To: ["source","task","page","decision","handoff","issue","wiki"]

// toolDefs arrays (lines 207, 233, 268):
// Same enum additions
```

### Full-Repo Sync Flow

```
1. Operator: GITCODE_E2E_REPO_ID=X GITCODE_TOKEN=y gitcode-mcp sync --live --full
2. CLI: parseOptions sets --live flag
3. Factory: NewLiveProvider(token) → NewWithClient(store, liveClient)
4. Dispatch: sync --full → Service.SyncRepo(ctx, repoID)
5. SyncRepo:
   a. issues = client.ListIssues(repoID, state:"all", paginate)
   b. for each issue: SyncToCache(remote_alias=issue.Number, remote_type="issue")
   c. pages = client.ListWikiPages(repoID, paginate)
   d. for each page: SyncToCache(remote_alias=page.Slug, remote_type="wiki")
6. Each SyncToCache: existing pipeline (idempotency key, writer lock, fetchAndStage, dedup, audit event)
7. Result: SyncRepoResult{IssueCount, WikiCount, Skipped, Updated, Inserted, Failures}
```

### Two-Cache E2E Flow

```
func TestE2ELiveTwoCache(t *testing.T) {
    // Pre: GITCODE_E2E_REPO_ID, GITCODE_E2E_OWNER, GITCODE_E2E_REPO, GITCODE_TOKEN set
    token, ok := gitcode.RequireLiveProviderForTest()
    if !ok { t.Skip("live e2e requires GITCODE_LIVE_TEST=1 and token") }
    
    cacheA := t.TempDir() + "/cache-a.db"
    cacheB := t.TempDir() + "/cache-b.db"
    defer os.Remove(cacheA); defer os.Remove(cacheB)
    
    // Phase 1: Bind and sync cache A
    svcA := buildLiveService(t, cacheA, token)
    svcA.AddRepository(ctx, ...)
    svcA.SyncRepo(ctx, ...)  // full-repo sync
    svcA.CreateIssue(ctx, WriteCommandRequest{Title:"e2e-test", Mode:WriteModeLive})
    
    // Phase 2: Re-sync cache A, verify no duplicate records
    resultA2 := svcA.SyncRepo(ctx, ...)
    require.Zero(t, resultA2.Inserted)
    
    // Phase 3: Create cache B, sync from same repo
    svcB := buildLiveService(t, cacheB, token)
    svcB.AddRepository(ctx, ...)
    svcB.SyncRepo(ctx, ...)
    
    // Phase 4: Assert equivalence
    // Compare record count, content hashes, comment counts per source
    assertCacheEquivalence(t, svcA, svcB, repoID)
}
```

## Evidence Coverage

| Evidence Family | Coverage | Status |
|----------------|----------|--------|
| Provider selection factory wiring | Full | `internal/gitcode/provider.go`, `internal/service/service.go:30-38`, `cmd/gitcode-mcp/main.go:298-315`, `internal/cli/cli.go:190-199` |
| Credential handling / Keychain | Strong (env), Weak (Keychain) | `internal/config/effective.go:69-160`, `internal/config/runtime_audit.go:34-87` |
| Live sync pipeline | Strong (single-item), Weak (full-repo) | `internal/service/service.go:753-1205`, `internal/gitcode/models.go:5-112` |
| Live write / idempotency | Strong (engine), Weak (wired) | `internal/service/service.go:840-878,1400-1667`, `internal/cache/models.go:135-147` |
| Two-cache e2e harness | Absent | No `internal/e2e/` directory, no `//go:build e2e` tag |
| Stale-index false positives | Strong (logic), Gap (root cause) | `internal/index/stale.go:35-176`, `internal/service/service.go:563-592` |
| Source search after sync/index | Strong (service layer), Gap (MCP validation) | `internal/service/service.go:255-294`, `internal/mcp/mcp.go:778-785` |
| MCP kind enum fix | Strong (localized) | `internal/mcp/mcp.go:198-351,778-785` |
| CLI help subcommand discovery | Strong (gap characterized) | `internal/cli/cli.go:964-1015` |
| Cache schema migration | Strong | `internal/cache/schema.go:1-422`, `internal/cache/sqlite.go:49-101` |
| Doctor/readiness command | Moderate | `internal/config/runtime_audit.go:1-131`, `cmd/gitcode-mcp/main.go:318-347` |
| MCP parity validation | Moderate | `internal/mcp/mcp.go:1-1273`, `internal/mcp/transport_http_sse.go` |
| Documentation updates | Strong (existing docs), Gap (live-readiness.md) | 14 docs in `docs/` |

## Evidence Gaps And Negative Findings

### Unimplemented Paths (Blocking)

1. **Runtime provider selection** — `defaultServiceFactory` and both MCP paths hardcode `service.New(store)`. The `--live` flag is parsed but never consumed. No code exists to switch from fixture to live client. **Affects Tasks 1, 3, 4, 5, 12.**

2. **macOS Keychain provider** — No `go-keyring` or `99designs/keyring` in `go.mod` (ext8). `StaticCredentialProvider` is defined but never wired to Keychain. **Affects Task 2 scope for native Keychain.**

3. **Two-cache e2e harness** — No `internal/e2e/` directory. No `//go:build e2e` build tag. No multi-cache equivalence logic. No redacted output capture patterns. No cleanup-on-failure guarantee. **Affects Task 5.**

4. **Full-repo sync** — `SyncRequest` handles single aliases only. CLI `--issues` hardcodes `issue:42`, `--wiki` hardcodes `wiki:Home`. No batch discovery/iteration logic. **Affects Task 3 acceptance criteria.**

5. **Per-command help text** — No mechanism to display command-specific help. Flag package's `ContinueOnError` discards help requests. **Affects Task 9.**

### Partially Implemented Paths (Needs Wiring)

6. **Live write** — Entire pipeline implemented (validation, idempotency, audit trail, three-phase, replay, dry-run) but inoperative due to fixture client default. Write credential guard checks `os.Getenv` directly, bypassing `ChainCredentialProvider`. **Affects Task 4.**

7. **Live sync** — Individual-item pipeline fully implemented with idempotency, retry, error normalization, WAL checkpointing. Only needs provider wiring and batch discovery. **Affects Task 3.**

8. **Doctor command** — `--runtime-audit` mode exists but produces config/credential only. No cache state, schema version, sync time, index freshness, or MCP health. Without `--runtime-audit`, returns error. **Affects Task 11.**

9. **MCP kind enums** — `validKind()` and 3 `toolDef` schema arrays need `"issue"` and `"wiki"` added. Fix is isolated to `internal/mcp/mcp.go`. **Affects Tasks 7, 8.**

10. **`auth status` preflight** — Does not call `ProbeAuth` against live API. Reports token presence but not validity. **Affects Task 2 acceptance criteria.**

### Design Gaps

11. **Conflict detection at write time** — Adapter supports `ErrConflict` but no `If-Match`/`ETag` precondition exists. Unknown if GitCode API supports conditional writes.

12. **Label management** — `AddLabel`/`RemoveLabel` are deferred stubs returning immediate errors. No implementation path.

13. **`ErrCacheEmpty` ambiguity** — `SearchSources` returns `ErrCacheEmpty` for both "no matching results" and "empty cache" — no differentiation.

14. **Migration backup** — No automatic backup before migration. No dry-run or preview mode. Error messages lack remediation steps.

## Findings By Component Or Concern

### Provider Selection (Task 1)
- `service.NewWithClient` is the injection vector. `defaultServiceFactory` must accept deps to build live client when `--live` is set. MCP serve paths need identical injection.
- `RequireLiveProviderForTest()` provides the test-gate pattern for `//go:build e2e` tests.
- `NewUnavailableProvider("fixture client is read-only")` provides the error message for ops without `--live`.

### Credential Handling (Task 2)
- Env token baseline is complete and redacted. `ChainCredentialProvider` supports fallback chaining — adding a Keychain provider requires only implementing `CredentialProvider` interface and appending to the chain.
- `auth status` needs a `--keychain` flag and a `ProbeAuth` call to validate token against live API.
- Missing-token diagnostic should enumerate available sources: "Set GITCODE_TOKEN or store a token in the macOS Keychain with service=gitcode-mcp account=default."

### Live Sync (Task 3)
- Single-item pipeline is proven. Full-repo sync needs `client.ListIssues` and `client.ListWikiPages` calls iterating over paginated results, then `SyncToCache` per item.
- Rate-limit handling exists in `normalizeSyncFailure` and `isRetryableSyncError`. CLI should report rate-limit status clearly.
- Delta detection: Content hash deduplication prevents duplication. Sync event records track deltas via `Skipped`/`Updated`/`Inserted` counts.

### Live Write (Task 4)
- Entire pipeline is code-complete except provider wiring. `AddLabel` is the only stub.
- `--dry-run` validates inputs, builds adapter route, computes idempotency key, returns `{Status:"dry_run_valid"}` — no adapter call.
- Conflict detection: Adapter returns `ErrConflict` → normalized to `write_conflict`. No precondition headers.
- Write credential guard must use `ChainCredentialProvider` instead of raw `os.Getenv`.

### Two-Cache E2E (Task 5)
- `RequireLiveProviderForTest()` pattern gates on env vars. `t.TempDir()` provides isolated cache directories with automatic cleanup.
- Redaction: Must wrap `t.Logf` to scan for token patterns, URLs containing owner/repo, and raw API bodies. Or use a `LogRedactor` wrapper.
- Equivalence: Compare record count, content hash per source, comment count per source, remote version per source, sync event count.

### Stale-Index Fix (Task 6)
- Hash comparison logic (`currentHash != "" && state.ContentHash != "" && currentHash != state.ContentHash`) is correct. Root cause likely in `indexed_at` metadata: if `InheritedMetadata["indexed_at"]` is zero-valued after a fresh index, `IndexFreshnessRecord.IndexedAt` will be `time.Time{}` (year 0001), which may trigger a false staleness path or confuse operators.
- Fix: Ensure `indexSourceRecord` correctly propagates `indexed_at` to chunk metadata, and ensure `BuildFreshnessReport` does not treat zero `IndexedAt` as a staleness signal.
- `sync --index` should chain `Index()` after `SyncToCache()` when both flags are present.

### Source Search Fix (Task 7)
- `Service.SearchSources` is correct — queries store, returns results with actual kind from database.
- `validKind()` at MCP layer rejects `"issue"`/`"wiki"` — fix by adding these to the allowed list.
- `ErrCacheEmpty` ambiguity: Consider returning empty result set with zero results instead of error when cache has records but none match.

### MCP Kind Enums (Task 8)
- Fix `validKind()` and 3 `toolDef` Enum arrays. Add `"issue"` and `"wiki"`. Consider keeping `"task"` and `"doc"` for seed corpus compatibility.
- Kind descriptions should list valid values: `"Source kind filter. Valid values: issue, wiki."`

### CLI Help (Task 9)
- Implement `parseOptions` handling for `--help` flag: when present, print command-specific help and `os.Exit(0)`.
- Each command needs a help text mapping: command name → usage, description, flags, examples.
- `doctor` and `auth` without subcommands should print help text, not `"subcommand is required"`.

### Cache Migration (Task 10)
- Add `gitcode-mcp migrate-cache --dry-run` command that opens store, reports current version, reports target version, lists pending migrations, and exits without applying.
- `migrate-cache` (without `--dry-run`) applies pending migrations and reports results.
- Error message for incompatible schema: `"cache schema version X is not compatible with current version Y. Re-initialize cache with gitcode-mcp config init --cache-path <path>."`
- Doctor command should report schema version.

### Doctor/Readiness (Task 11)
- Doctor without flags should produce a comprehensive report. Remove `--runtime-audit` requirement (or make it the default).
- Extend `RuntimeAuditConfigReport` or create `ReadinessReport` with: binary version, config path/source, cache path, schema version, repo binding (owner/repo/bound/id), token source (redacted), live provider available (probe), auth probe result, last sync timestamp, sync event count, index freshness (stale count, fresh count, missing count), MCP transport health.
- Subsystem integration: Doctor opens cache store (read-only), queries `schemaVersion`, counts sources via `RecordCounts`, finds latest `SyncEvent` by `created_at`, runs `FreshnessCheck` on all sources, checks MCP readiness probe.

### MCP Parity (Task 12)
- All 7 read tools (`cache_status`, `list_sources`, `get_source`, `sync_status`, `list_chunks`, `search_chunks`, `search_sources`) are implemented. Parity validation requires:
  1. Live-sync a cache.
  2. Launch MCP server in stdio mode against that cache.
  3. Send JSON-RPC `tools/call` for each read tool.
  4. Assert non-error response with structured content.
- Can be implemented as a `//go:build e2e` test or as a standalone validation script.
- Keychain wrapper integration test: `go test -run TestMCPKeychainWrapper -tags=e2e` launches `gitcode-mcp --mcp` via wrapper path and validates tool responses.

### Documentation (Task 13)
- Create `docs/live-readiness.md`: Operator setup guide with sanitized placeholders for env vars. Walkthrough: bind repo, set token, sync, write, verify.
- Update `docs/architecture.md`: Add provider-selection decision tree, credential flow diagram, live/sync/write component entries.
- Update `docs/cache-and-sync-model.md`: Document live sync event semantics, partial failure behavior, migration policy.
- Update `docs/secrets.md` or create `docs/public-safety.md`: Sanitization rules for live transcripts, fixtures, test output.
- Update `docs/config-reference.md`: Document credential config fields, provider mode settings.

## Comparative External Systems

No external web sources were retrieved for comparison. The following inferences are drawn from codebase design patterns:

- **Go CLI patterns**: The codebase follows standard Go CLI conventions (flag package, explicit command dispatch, no framework dependency). This is consistent with tools like `gh`, `docker`, and `kubectl` but simpler.
- **MCP protocol**: Follows standard MCP JSON-RPC 2.0 over stdio and SSE. The tool registration pattern (schema definitions with input validation) mirrors the MCP specification's `tools/list` → `tools/call` flow.
- **SQLite migration patterns**: The forward-only, auto-detecting, per-transaction migration system is standard and comparable to `golang-migrate/migrate` or Django's migration framework, albeit simpler.
- **Idempotency pattern**: The SHA256-hash-based idempotency key derivation (content-addressed) is standard for write APIs (Stripe, GitHub API). The audit trail replay pattern is consistent with event-sourcing approaches.

## Engineering Implications For Later Design

1. **Provider interface vs. Client interface divergence**: The codebase defines both `gitcode.Provider` (with `ProbeAuth`, `GetRepo`, etc.) and `gitcode.Client` (used by `Service`). These are parallel but not unified. `liveProvider` embeds `*HTTPClient` which implements both. Future iterations should consider unifying or clearly documenting the split.

2. **Credential provider chain extensibility**: `ChainCredentialProvider` supports arbitrary provider ordering. A future `OAuthCredentialProvider` or `VaultCredentialProvider` can be added without changing the interface. The `StaticCredentialProvider` pattern for test injection is well-designed.

3. **Sync event as audit log**: Every sync and write operation produces immutable `SyncEvent` or `AuditTrailEntry` records with idempotency keys. This provides a foundation for eventual consistency verification, cross-cache reconciliation, and compliance audit trails.

4. **Cache migration compatibility**: The v4 schema with auto-detection of existing columns enables additive migrations without breaking old caches. Future schema changes should follow the same pattern: add columns via `CREATE TABLE IF NOT EXISTS` + `PRAGMA table_info`, never drop columns.

5. **E2E test infrastructure**: The `//go:build e2e` tag pattern and `RequireLiveProviderForTest()` gate should become the standard pattern for all tests that touch live APIs, ensuring `go test ./...` remains offline.

## Follow-Up Questions For Later Design

1. Does the GitCode API return `ETag` or `Last-Modified` headers on issue/wiki resources that could support conditional writes (`If-Match`/`If-Unmodified-Since`)?

2. What is the rate-limit header format (`Retry-After` seconds vs. `X-RateLimit-Reset` timestamp vs. `RateLimit-Remaining`)?

3. What is the maximum page size for `ListIssues` and `ListWikiPages`? Is there a hard cap?

4. Does the GitCode API support label CRUD? If not, should `AddLabel`/`RemoveLabel` be removed from the adapter interface?

5. Should the `Provider` interface and `Client` interface be unified in a future iteration, or is the split intentional (Provider = factory, Client = transport)?

6. Is the `InheritedMetadata["indexed_at"]` zero-value the root cause of false `stale_index` warnings, or is the issue in hash comparison?

## Source Quality Notes

All evidence is drawn from direct source code inspection of the target repository. Sources are authoritative (the canonical implementation) but reflect only the iteration 2 state. No external references, published papers, or third-party library documentation were consulted. Freshness risk is low since the analysis is against the current `main` branch state. The evidence is complete for characterizing existing mechanisms and gaps; the primary uncertainty is in the GitCode live API behavior (rate limits, pagination, conditional writes) which can only be resolved through live testing in the implementator phase.

## Runner Evidence
- Final message: `runa/calls/call-0054-run_external_research/attempt-1/final_message.txt`
