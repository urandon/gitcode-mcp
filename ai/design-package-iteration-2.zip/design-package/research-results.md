# Research Results

## Research Index
# Research Index

## Competitor Research
- Model Context Protocol: `source document`
- GitHub CLI: `source document`
- Git Credential Manager: `source document`
- go-keyring: `source document`
- 99designs keyring: `source document`

## External Research

## Competitor Analysis

### Reference Study: GitHub CLI

GitHub CLI implements auth, config, repository targeting, hosted-repo reads/writes, safety prompts, and user-facing diagnostics through small Cobra commands wired around shared config, auth, repo, JSON, and I/O utilities.
Its key architectural choice is to separate command ergonomics from execution seams through options structs, factory-injected clients/config/prompters, and reusable helpers such as repo override, JSON output, auth checks, and environment-variable documentation.
The strongest transferable idea for `gitcode-mcp` is a repo-scoped, explicit, testable CLI contract with redacted auth status, environment precedence diagnostics, `--repo`/env override semantics, JSON parity, and safe write gates.

### Reference Study: Git Credential Manager

Git Credential Manager implements cross-platform credential UX through explicit store selection, platform defaults, environment/config precedence, and a `diagnose` command that exercises environment, filesystem, networking, Git, credential-store, and auth checks - evidence: `docs/credstores.md:3`, `src/shared/Core/Commands/DiagnoseCommand.cs:24`.
Its key architectural choice is a common credential-store interface with a lazy platform-specific backing store and validation errors that point users to supported options - evidence: `src/shared/Core/ICredentialStore.cs:8`, `src/shared/Core/CredentialStore.cs:54`.
The strongest transferable idea for `gitcode-mcp` is a redacted, explicit `config/auth/doctor` UX that separates routine safe status from opt-in secret tracing or live validation - evidence: `docs/environment.md:48`, `src/shared/Core/Commands/DiagnoseCommand.cs:184`.

### Reference Study: go-keyring

go-keyring provides a small Go API for setting, getting, deleting, listing, and test-mocking secrets across macOS, Linux/BSD, Windows, and unsupported-platform fallback paths, with OS-specific implementations selected by platform files (`keyring.go:23`, `keyring_darwin.go:200`, `keyring_unix.go:215`, `keyring_windows.go:129`, `keyring_fallback.go:8`).
Its key architectural choice is a single package-level `Keyring` provider interface backed by platform adapters and overridable by an in-memory mock for tests (`keyring.go:7`, `keyring.go:23`, `keyring_mock.go:76`).
The strongest transferable idea for gitcode-mcp is to hide native credential-store differences behind a minimal service/user/token abstraction, expose redacted diagnostics around presence/errors, and test credential UX with a mock store instead of touching real OS stores (`README.md:212`, `keyring_mock.go:89`).

### Reference Study: 99designs keyring

99designs keyring implements a Go credential-storage abstraction over macOS Keychain, Windows Credential Manager, Linux Secret Service/KWallet/KeyCtl, pass, and encrypted file storage.
Its key architectural choice is a small uniform `Keyring` interface plus ordered backend selection and backend-specific configuration knobs rather than a single direct OS wrapper.
The strongest transferable idea for `gitcode-mcp` is to expose explicit credential-store selection, diagnostics, and mockable prompt/store interfaces while avoiding silent insecure fallback.

### Reference Study: Model Context Protocol

Model Context Protocol defines a JSON-RPC 2.0 agent-facing protocol with tool discovery/call surfaces, resource reads, lifecycle negotiation, and stdio plus Streamable HTTP transports.
Its key architectural choice is to keep the protocol transport-agnostic while standardizing message shape, initialization, capability negotiation, and HTTP/SSE connection behavior.
The strongest transferable idea for GitCode MCP is to implement CLI/MCP read parity as typed cache-first tools with stable JSON schemas, then expose the same server over stdio and a localhost-default Streamable HTTP endpoint.

## External Research

index.md
```md
# Executive Summary

- No external source candidates, component evidence, or source ids were supplied.
- Because live web search is prohibited and no `sources.json` evidence exists, this synthesis cannot make concrete source-backed external claims about MCP transports, GitCode APIs, SQLite/WAL behavior, credential stores, CLI ergonomics, or comparable systems.
- The only evidence-supported finding is negative: the requested second-iteration design depends on several external mechanism families that remain unevidenced.
- Later design should treat this research output as an evidence gap register, not as an architecture recommendation or implementation plan.
- Any final gap-closure design should first collect authoritative references for:
  - MCP stdio and HTTP/SSE or streamable HTTP transport behavior.
  - GitCode issue, comment, wiki, auth, pagination, conflict, and rate-limit APIs.
  - `modernc.org/sqlite` behavior with SQLite WAL, busy timeouts, migrations, and concurrent access.
  - Cross-platform credential-store patterns.
  - Public-safe fixture capture and redaction practices.
  - CLI config discovery and diagnostics precedents.

# Research Scope And Source Strategy

## Scope

The requested research scope covers external mechanisms relevant to a Go-based, cache-first GitCode MCP/CLI system:

- Repository-scoped identity and aliasing.
- Explicit sync/bootstrap into SQLite.
- Offline CLI and MCP read paths.
- MCP stdio and HTTP/SSE transport behavior.
- Multi-client cache concurrency.
- Credential/config UX.
- GitCode issue/wiki write semantics.
- Chunking, citations, snapshots, and deterministic corpus export.
- Sanitized fixture and optional credential-gated live validation.

## Source Strategy

- Primary evidence base requested: curated source candidates, component evidence, and component synthesis.
- Supplied curated source candidates: none.
- Supplied component evidence: empty object.
- Supplied component synthesis: explicitly states no traceable implementation or external mechanism findings.
- Live web search: prohibited by the task rules.
- Local target-repository inspection: prohibited by the role instructions.

## Resulting Evidence Posture

| Evidence family | Available? | Consequence |
|---|---:|---|
| Official GitCode API docs | No | Cannot specify source-backed API behavior. |
| MCP transport specs | No | Cannot state current protocol transport compatibility. |
| SQLite / `modernc.org/sqlite` docs | No | Cannot make source-backed concurrency claims. |
| Credential-store docs | No | Cannot compare Keychain, Secret Service, `pass`, Windows Credential Manager. |
| Existing `gitcode-mcp` code/tests/docs | No | Cannot validate current state or component boundaries. |
| Comparable CLI/MCP systems | No | Cannot draw external precedent claims. |

# Relevant Existing External Mechanisms

No relevant existing external mechanisms can be source-backed from the supplied evidence.

The following mechanism families are relevant by request scope, but remain unevidenced:

| Mechanism family | Why relevant | Evidence status |
|---|---|---|
| MCP stdio transport | Required local single-client mode | No source supplied. |
| MCP HTTP/SSE or successor HTTP transport | Required multi-client/shared-server mode | No source supplied. |
| GitCode tracker issue API | Required sync and write path | No source supplied. |
| GitCode wiki/page API | Required sync and write path | No source supplied. |
| SQLite WAL/read concurrency | Required one-cache/many-reader behavior | No source supplied. |
| SQLite busy timeout / migration locking | Required typed contention behavior | No source supplied. |
| Cross-platform credential stores | Required auth/config UX | No source supplied. |
| Deterministic chunk/citation export precedents | Required RAG-ready cache export | No source supplied. |

# Design-Critical Unknowns

## GitCode API Unknowns

- Whether GitCode exposes stable APIs for:
  - Issue list/get/create/update.
  - Issue comments list/create/update.
  - Wiki page list/get/create/update.
  - Pagination.
  - Conditional updates or conflict detection.
  - ETags, updated timestamps, version ids, or source fingerprints.
  - Auth status and permission diagnostics.
  - Rate-limit and retry headers.
- Whether wiki identifiers are slug-based, path-based, numeric, branch-backed, or repository-default-branch dependent.
- Whether issue numbers and wiki slugs are globally unique or repository-local only.
- Whether issue body updates and comment mutations have separate conflict semantics.

## MCP Transport Unknowns

- Whether HTTP/SSE remains the right current transport name or whether newer MCP transport terminology should be used.
- Required endpoint shapes for HTTP/SSE-compatible clients.
- Client compatibility expectations for Codex, editors, workflow components, and remote agents.
- Whether request correlation ids are a protocol feature, application convention, or log-only concern.
- Whether server readiness should be exposed through MCP tools, plain HTTP health endpoints, or both.

## SQLite / Cache Concurrency Unknowns

- Confirmed behavior of `modernc.org/sqlite` for:
  - WAL mode.
  - Busy timeout configuration.
  - Shared cache or connection pool behavior.
  - Concurrent readers during writer transactions.
  - Migration lock ownership across processes.
- Whether one long-lived HTTP server should be the only writer, or whether separate CLI sync/index invocations can safely coordinate through database locks.
- Whether cache ownership metadata should live in SQLite, a sidecar lock file, or both.

## Credential UX Unknowns

- Which credential storage mechanisms should be first-class commands versus documented wrappers.
- Whether `auth login` can be implemented safely without browser/OAuth support.
- Whether token discovery precedence should prefer environment variables, OS credential stores, config references, or command-line flags.
- How to make redacted config output public-safe across platforms.

## Corpus Integrity Unknowns

- Required citation granularity for issue bodies, comments, wiki pages, and projections.
- Whether line/byte/character offsets are stable enough across normalized markdown exports.
- Whether snapshot ids should address raw source records, derived chunks, or complete cache state.
- How to detect stale chunks after source mutation.

# Architecture Alternatives And Trade-Offs

The alternatives below are framed as research questions, not recommendations, because no external mechanism evidence was supplied.

## MCP Transport Shape

| Alternative | Potential advantage | Potential failure mode | Evidence need |
|---|---|---|---|
| Stdio-only local server | Simple client launch and process lifetime | Cannot support shared multi-client cache owner | MCP stdio docs and client behavior |
| HTTP/SSE shared server | Enables one cache owner and many clients | Transport naming or compatibility may be outdated | MCP HTTP/SSE or current HTTP transport specs |
| Dual transport with same tool layer | Keeps local compatibility and shared mode | Risk of divergent behavior if transports are separately implemented | Protocol conformance references and tests |

## Cache Ownership Model

| Alternative | Potential advantage | Potential failure mode | Evidence need |
|---|---|---|---|
| SQLite lock-only coordination | Minimal components | Poor diagnostics if lock contention is opaque | SQLite and driver lock behavior |
| App-level ownership table | Typed ownership and stale-owner diagnostics | Requires careful transaction semantics | SQLite transaction behavior |
| Single long-lived writer process | Simplifies writes and indexing | CLI sync/index commands need RPC path or careful coordination | MCP/server lifecycle evidence |

## Credential Strategy

| Alternative | Potential advantage | Potential failure mode | Evidence need |
|---|---|---|---|
| Environment-variable token only | CI-friendly and simple | Poor desktop UX; easy secret leakage in shell history/logs | Public-safe secret handling precedents |
| OS credential store wrappers | Better local secret hygiene | Cross-platform inconsistency | Platform credential-store docs |
| Native `auth` commands | Best UX | Higher implementation and security burden | GitCode auth API and platform docs |
| Config file token reference, not token value | Reduces config leakage | Indirection can confuse users | CLI config UX precedents |

## Source-of-Truth Model

| Alternative | Potential advantage | Potential failure mode | Evidence need |
|---|---|---|---|
| GitCode-only canonical records | Clear sync and conflict model | Local-only projections need explicit import/write workflow | GitCode identity/version behavior |
| Local markdown as peer source | Easy migration bridge | Can split truth and create alias collisions | Import/export precedent and conflict strategy |
| Cache projections only | Strong offline read path | Requires explicit refresh and stale-index diagnostics | Cache/index integrity evidence |

# Primary Decision Hierarchy

Because source evidence is absent, later design should resolve decisions in this order:

1. **Protocol correctness**
   - Establish current MCP transport names, endpoint shapes, and compatibility expectations.
2. **GitCode identity and API truth**
   - Establish repository scope, issue/wiki identity, auth, pagination, mutation, and conflict behavior.
3. **Cache concurrency safety**
   - Establish SQLite/driver settings and process-level lock semantics.
4. **Credential and config safety**
   - Establish cross-platform secret storage and redaction behavior.
5. **Offline read contract**
   - Establish deterministic CLI/MCP parity after explicit sync/index.
6. **Write safety**
   - Establish dry-run, idempotency, conflict detection, and audit semantics.
7. **Corpus integrity**
   - Establish chunk/citation/snapshot invariants.
8. **Documentation and public-safety**
   - Establish redaction, fixture capture, and live-test boundaries.

# Low-Level Implementation Details

No low-level implementation details can be source-backed.

The following details are design-sensitive and require evidence before being fixed:

| Area | Detail needing evidence |
|---|---|
| MCP HTTP/SSE | Exact URL paths, stream format, message framing, initialization behavior, client config schema. |
| MCP stdio | Process lifecycle, stderr/stdout separation, logging behavior, graceful shutdown. |
| SQLite | DSN parameters, WAL activation, busy timeout, transaction isolation, connection pooling, migration locks. |
| Config | Default paths, environment override precedence, redacted effective config schema. |
| Credentials | Token lookup order, OS credential-store command wrappers, noninteractive CI mode. |
| GitCode sync | Endpoint shapes, pagination cursors, updated-since support, tombstone/deletion behavior. |
| GitCode writes | Idempotency keys, conflict preconditions, comment ids, wiki version handling. |
| Chunking | Source offset type, heading parsing, max-size split behavior, sliding-window metadata. |
| Snapshots | Snapshot id derivation, stored manifest shape, missing-index warnings, diff semantics. |

# Evidence Coverage

| Required section area | Evidence coverage |
|---|---|
| Executive gap summary | Covered only as evidence absence. |
| External mechanisms | Not covered. |
| Architecture alternatives | Covered as uncited research alternatives only. |
| Decision hierarchy | Covered as evidence collection priority. |
| Low-level implementation details | Covered only as unresolved evidence needs. |
| Comparative systems | Not covered. |
| Engineering implications | Covered only as later-design cautions. |
| Component findings | Negative only. |

# Evidence Gaps And Negative Findings

## Negative Findings

- No external source candidates were supplied.
- No component evidence was supplied.
- No source ids exist for citation.
- No traceable support exists for claims about:
  - Current `gitcode-mcp` behavior.
  - Current MCP tool surface.
  - Existing CLI command coverage.
  - Existing cache schema.
  - Existing sync/index/write seams.
  - Existing docs accuracy.
  - GitCode API semantics.
  - MCP HTTP/SSE compatibility.
  - SQLite concurrency settings.
  - Credential-store behavior.

## Evidence Gaps

| Gap | Risk if unresolved |
|---|---|
| MCP transport spec evidence | Implementing obsolete or incompatible HTTP/SSE behavior. |
| GitCode API evidence | Designing sync/write paths that cannot be implemented. |
| SQLite concurrency evidence | Race conditions, deadlocks, or misleading lock diagnostics. |
| Credential-store evidence | Unsafe token handling or poor cross-platform UX. |
| Fixture/redaction evidence | Public repository contamination with secrets or private data. |
| Snapshot/chunk evidence | Non-deterministic exports and unverifiable citations. |
| Existing runtime evidence | Gap-closure design may miss actual implementation constraints. |

# Findings By Component Or Concern

## Runtime Gap Audit

- Direct evidence: none.
- Inference from request: a future audit command is desired.
- Unknowns:
  - Existing installed binary behavior.
  - Existing config discovery behavior.
  - Existing cache/index state reporting.
  - Existing MCP surface.

## Repository Binding

- Direct evidence: none.
- Inference from request: repository scope is design-critical because remote aliases may collide.
- Unknowns:
  - GitCode owner/repo/base-url identity model.
  - Whether additional project, branch, wiki, or namespace metadata is required.

## Config And Credentials

- Direct evidence: none.
- Inference from request: token/config UX is currently a dogfood blocker.
- Unknowns:
  - Safe precedence order.
  - Native versus wrapper-based credential storage.
  - Redaction rules.

## Cache Bootstrap And Sync

- Direct evidence: none.
- Inference from request: explicit network sync must populate issue/wiki records before offline reads.
- Unknowns:
  - GitCode API availability.
  - Idempotency and deletion semantics.
  - Index trigger semantics.

## CLI Read Path

- Direct evidence: none.
- Inference from request: CLI reads should be deterministic, repo-scoped, and offline after sync.
- Unknowns:
  - Existing command names and output formats.
  - Existing test fixture shape.

## MCP Tool Parity

- Direct evidence: none.
- Inference from request: current MCP surface may lag service/CLI operations.
- Unknowns:
  - Existing JSON-RPC schemas.
  - Tool argument and response conventions.
  - How warnings/errors are represented.

## MCP Transports

- Direct evidence: none.
- Inference from request: stdio and shared HTTP/SSE are both required scenarios.
- Unknowns:
  - Current MCP transport terminology.
  - Endpoint shape and compatibility.

## Multi-Client Cache Concurrency

- Direct evidence: none.
- Inference from request: one shared cache must support many readers and serialized writers.
- Unknowns:
  - SQLite driver behavior.
  - Process lock design.
  - Migration ownership.

## GitCode Writes

- Direct evidence: none.
- Inference from request: fake-success write stubs are unacceptable.
- Unknowns:
  - Remote mutation APIs.
  - Conflict and audit metadata.

## Source-of-Truth Semantics

- Direct evidence: none.
- Inference from request: GitCode tracker/wiki records are canonical; local files are projections.
- Unknowns:
  - How imported projections map to canonical records.
  - How projection-only aliases are represented.

## Snapshots, Chunks, Citations

- Direct evidence: none.
- Inference from request: snapshot and diff behavior must be truthful and chunk-aware.
- Unknowns:
  - Snapshot storage model.
  - Citation range stability.
  - Missing-index warning format.

## Chunking Policy

- Direct evidence: none.
- Inference from request: heading-delimited default and sliding-window optional policy are desired.
- Unknowns:
  - Markdown parser choice.
  - Offset/citation model.
  - Determinism requirements.

## API Discovery And Validation

- Direct evidence: none.
- Inference from request: fixture-backed tests plus optional live validation are required.
- Unknowns:
  - Credential gating mechanism.
  - Redaction pipeline.
  - Live test repository constraints.

## Documentation

- Direct evidence: none.
- Inference from request: docs must be public-safe and executable.
- Unknowns:
  - Existing docs state.
  - Docs smoke-test mechanism.

# Comparative External Systems

No comparative external systems can be source-backed.

Potential comparison families for later evidence collection:

| System family | Why it may be useful later |
|---|---|
| MCP SDK/server implementations | Transport naming, stdio/HTTP behavior, client compatibility. |
| GitHub/GitLab CLIs | Config discovery, auth status, redacted config, issue/wiki-like workflows. |
| SQLite-backed local-first tools | WAL, locking, migration ownership, read/write concurrency. |
| Static-site/wiki exporters | Deterministic markdown chunking, citations, snapshots. |
| Secret-management CLIs | Cross-platform token storage and headless fallback UX. |

# Engineering Implications For Later Design

- Do not freeze an HTTP/SSE endpoint contract until current MCP transport references are collected.
- Do not define GitCode write semantics until issue/comment/wiki mutation APIs are validated.
- Do not rely on generic SQLite concurrency assumptions without `modernc.org/sqlite`-specific confirmation.
- Do not document credential storage as secure without platform-specific evidence and redaction tests.
- Treat repository-scoped identity as a likely invariant, but validate required GitCode metadata before schema finalization.
- Keep local markdown ingest explicitly separate from canonical GitCode records until import/write semantics are validated.
- Require all live API validation to be opt-in, credential-gated, and redacted before durable storage.
- Keep fixture tests as the baseline because no external availability can be assumed.

# Follow-Up Questions For Later Design

## MCP

1. What is the current authoritative MCP transport specification for stdio and HTTP-based streaming?
2. Is “HTTP/SSE” still the correct implementation target, or should the design use newer MCP transport terminology?
3. What endpoint shape do target clients require?
4. How should health/readiness endpoints coexist with MCP protocol endpoints?

## GitCode API

1. What endpoints exist for issues, comments, and wiki pages?
2. What identifiers are stable across syncs?
3. What conflict/precondition mechanisms exist for writes?
4. How are pagination, rate limits, deleted records, and auth errors represented?
5. Can wiki pages be updated atomically and versioned?

## SQLite / Cache

1. What DSN and pragmas are required for WAL and busy timeout under `modernc.org/sqlite`?
2. Can concurrent CLI and MCP processes safely share the same database?
3. Should migrations be single-process only?
4. How should stale lock ownership be detected and cleared?

## Credentials

1. Which credential-store integrations are essential for the first useful slice?
2. Should native `auth` commands exist immediately, or should documented wrappers suffice?
3. What is the exact token lookup precedence?
4. How are secrets redacted from logs, diagnostics, snapshots, and fixtures?

## Corpus

1. What range type should citations use?
2. How should issue comments be chunked relative to issue bodies?
3. What makes a snapshot id stable and truthful?
4. How are missing or stale chunks represented in CLI and MCP responses?

# Source Quality Notes

- No sources were supplied.
- No source ids are available.
- Therefore:
  - No concrete external claims are cited.
  - No source ranking is possible.
  - No authority or freshness assessment is possible.
  - No comparative mechanism can be validated.
- The source strategy for the next research pass should prioritize authoritative specifications and primary documentation before blog posts or inferred examples.
```

sources.json
```json
[]
```

## Runner Evidence
- Final message: `runa/calls/call-0056-run_external_research/attempt-1/final_message.txt`
