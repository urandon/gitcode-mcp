# Request Formalization Revision 1

## Main user request information
Design the second implementation iteration for `gitcode-mcp` as a gap-closure package against the current implemented runtime, not a blank-slate system. The goal is a minimum useful dogfood slice: install the Go binary, configure a token and repository binding, sync one GitCode issue and one wiki page into a SQLite cache, index deterministic chunks, read through CLI, attach MCP over stdio or HTTP/SSE, and perform equivalent cache-first reads offline.

Scope includes repository-scoped identity, GitCode tracker/wiki source-of-truth records, explicit sync/bootstrap, cache/index state, chunk/citation/snapshot integrity, MCP tool parity, shared HTTP/SSE transport, multi-client cache concurrency, configuration and credential UX, write-path semantics, public-safe docs, sanitized fixtures, and optional credential-gated live validation.

Constraints: keep the repository public-safe; do not expose private paths, credentials, cookies, bearer tokens, unsanitized API responses, private tracker/wiki names, or private source repository references. Routine reads must be cache-first and offline after sync. Live network use must be explicit. SQLite should remain pure-Go via `modernc.org/sqlite`. RAG embeddings/vector DB/reranking are deferred; this iteration should only make corpus/chunks/citations RAG-ready.

Likely affected components include CLI commands, MCP tools/transports, configuration loading, credential handling, GitCode API adapter seams, sync/bootstrap workflow, SQLite cache schema and locking, indexing/chunking, snapshot/export/diff behavior, diagnostics, tests/fixtures, and documentation.

## Decomposed tasks
### Task 1: Runtime gap audit
Description: Define the product-facing gap audit for current CLI, MCP, cache, docs, and installed dogfood behavior without making source-level implementation claims in this stage.
Acceptance Criteria: A developer runs a future `gitcode-mcp doctor --runtime-audit --repo <repo_id>` product command against a configured test repository, and the CLI reports installed version, active config, repository binding, cache state, MCP surfaces, sync/index readiness, and actionable failure classes; evidence is a local command run against sanitized fixtures or a credential-gated test repository.

### Task 2: Repository binding model
Description: Specify configured `repo_id` as the first-class scope for API base URL, owner, repo name, enabled issue/wiki scopes, display names, aliases, diagnostics, sync, reads, writes, snapshots, and conflict handling.
Acceptance Criteria: A developer runs `gitcode-mcp repo add` and `gitcode-mcp repo status --repo <repo_id>`, then CLI and MCP reads filtered by `repo_id` return only records for that configured repository while colliding aliases such as `issue:42` from another repository are rejected or disambiguated; evidence is a CLI integration test plus MCP server/API test using two fixture repositories.

### Task 3: Config and credential UX
Description: Define install, config discovery, redacted effective config, environment precedence, credential-store options, Keychain wrapper pattern, auth commands, and diagnostics across macOS, Linux, Windows, and CI/headless use.
Acceptance Criteria: A developer runs `gitcode-mcp config init`, `config locate`, `config show --redacted`, `auth status`, and `doctor`, and the CLI shows active config path, override sources, token presence without secret value, cache path resolution, and platform-specific next steps; evidence is local CLI tests with temporary config homes and mocked external OS credential stores only.

### Task 4: Cache bootstrap workflow
Description: Define explicit cache population from configured GitCode repository scopes, including issue/wiki/search/repo sync modes, local markdown/export bridge ingest, idempotency, cache locking, and index trigger semantics.
Acceptance Criteria: A developer runs `gitcode-mcp sync --repo <repo_id> --issues --wiki --index`, and the CLI stores at least one issue and one wiki page as source-of-truth cache records, records sync events, builds index chunks, and subsequent `search`, `get`, and `get-snippet` commands work with network disabled; evidence is a fixture-backed CLI integration test and an optional live test gated by credentials.

### Task 5: CLI read-path contract
Description: Define the canonical offline CLI read workflow for list, search, get, snippets, backlinks, recent changes, link checks, stale-index reports, cache status, chunk listing, export, and diff.
Acceptance Criteria: After a successful fixture sync/index, a developer disables network access and runs CLI read commands for search/get/snippet/backlinks/recent/link-check/stale-index/cache-status/list-chunks/export/diff, and each command returns repo-scoped deterministic output with nonzero issue/wiki coverage and clear stale or missing-index warnings; evidence is CLI integration tests over sanitized fixtures.

### Task 6: MCP tool parity
Description: Define MCP tools needed for coordinator usage: `get_snippet`, `recent_changes`, `link_check`, `stale_index_report`, `cache_status`, `search_chunks` or `list_chunks`, and repo-aware `sync_status`, alongside existing read tools.
Acceptance Criteria: An MCP client connects to the server and invokes existing plus new read tools with `repo_id` filters; responses match equivalent CLI reads for issue/wiki sources, snippets, chunks, backlinks, sync status, cache status, and stale-index warnings; evidence is MCP JSON-RPC/server tests over the same fixture cache.

### Task 7: MCP stdio and HTTP/SSE
Description: Define stdio single-client mode and shared HTTP/SSE server mode, including bind address, endpoint shape, client configuration, health/readiness, localhost defaults, remote-host deployment, request correlation, shutdown, and protocol compatibility research questions.
Acceptance Criteria: One developer starts `gitcode-mcp mcp serve --transport http-sse --bind 127.0.0.1:<port>` and two MCP clients query the same cache concurrently while a stdio launch still works for a single local client; health/readiness endpoints report ready state and request logs include correlation IDs; evidence is runtime MCP transport tests and a local multi-client smoke command.

### Task 8: Multi-client cache concurrency
Description: Define one-cache/many-reader behavior, serialized sync/index/write operations, migrations, cache ownership, SQLite WAL/busy-timeout expectations, and clear errors for lock contention.
Acceptance Criteria: With one shared cache database, two MCP clients perform concurrent reads while a sync/index operation holds the writer lock; reads continue where safe, conflicting writers receive a typed busy/owned error, and migrations are blocked when another process owns the cache; evidence is Go concurrency tests using a temporary SQLite cache.

### Task 9: GitCode write paths
Description: Define real issue create/update/body/comment and wiki page create/update operations with repository scope, dry run, idempotency keys or source fingerprints, conflict detection, audit trail, and no fake-success remote writes.
Acceptance Criteria: A developer runs write commands with `--dry-run` and then against a stubbed external GitCode provider; dry run performs no remote mutation, successful writes persist audit events and cache refresh state, conflicts return actionable errors, and unavailable adapters cannot report success; evidence is CLI/API tests with external-provider mocks plus optional credential-gated live tests.

### Task 10: Source-of-truth semantics
Description: Define tracker issues and wiki pages as canonical GitCode records, with local files and markdown exports treated only as projections, bridge imports, exports, or cache artifacts.
Acceptance Criteria: A developer imports a local markdown projection and then runs `sync --repo <repo_id>`; the cache preserves GitCode issue/wiki identities as canonical source records, marks projection provenance separately, and refuses to treat projection-only aliases as remote truth without an explicit import/write command; evidence is CLI integration tests with fixture projections.

### Task 11: Snapshot and diff integrity
Description: Define chunk population, citation ranges, repo-scoped aliases, export warnings, stored snapshot ids, truthful snapshot resolution, and diff behavior when snapshot ids are missing or stale.
Acceptance Criteria: A developer runs `index`, `export-snapshot`, and `diff-snapshot --base-id <id> --head-id <id>`; exports include chunks and citation ranges or explicit missing-index warnings, valid ids resolve to stored snapshots, and unknown ids return not-found errors instead of comparing current state to itself; evidence is CLI and service tests over fixture snapshots.

### Task 12: Chunking policy surface
Description: Define heading-delimited markdown chunking as default, max-section fallback at paragraph/line boundaries, sliding-window policy for changelogs/non-heading documents, and extension points for later retrieval experiments.
Acceptance Criteria: A developer indexes fixture issue/wiki/changelog documents using default and sliding-window policies; generated chunks are deterministic, cite source ranges, respect max-size settings, and are queryable through CLI and MCP chunk/snippet surfaces; evidence is local indexing tests plus CLI/MCP read tests.

### Task 13: API discovery and validation
Description: Define which GitCode API behaviors can be validated with sanitized fixtures now and which require credential-gated live probing against a test repository for issues, comments, wiki pages, auth, pagination, conflicts, and rate/error handling.
Acceptance Criteria: A maintainer runs fixture validation with no credentials and optional live validation with credentials; fixture tests pass offline, live tests are skipped unless explicitly enabled, and live responses are redacted before any durable artifact is written; evidence is local test commands and optional credential-gated server/API tests.

### Task 14: Documentation package
Description: Define durable public-safe docs for install quickstart, config reference, repository binding, secrets, stdio and HTTP/SSE MCP clients, read/write walkthroughs, troubleshooting/doctor, fixture capture, and dogfood notes.
Acceptance Criteria: A new developer follows the docs from install through config/token/repo sync/index/CLI read/MCP read using sanitized fixtures or a test GitCode repo, and every documented command either succeeds or returns the documented diagnostic; evidence is a docs smoke test script or local command transcript with redacted paths and secrets.

### Task 15: One-week dogfood plan
Description: Order implementation work for fastest dogfood value: config/repo binding, fixture sync/index, CLI reads, MCP parity, transport/concurrency, write semantics, snapshot integrity, docs, and live validation.
Acceptance Criteria: The follow-up implementer can run the ordered plan task by task, and after each day’s slice there is an executable product check showing incremental dogfood capability, culminating in offline CLI and MCP reads for one issue and one wiki page; evidence is a local command checklist tied to task-level tests.

### Task 16: Dogfood feedback loop
Description: Capture observations that should feed back into Triborg/Runa/design-agent configuration, especially runtime gap evidence, public-safety constraints, MCP install friction, and acceptance-criteria quality.
Acceptance Criteria: After the dogfood slice runs, a coordinator records a public-safe feedback note with observed friction, missing metadata, and design-agent prompt/config improvements, and no private paths, secrets, or private tracker/wiki names appear; evidence is a local validation command or lint check over the generated feedback artifact.

## Assumptions
- The current repository already has some first-iteration cache, service, CLI, MCP, and docs artifacts, but exact implementation details are intentionally deferred to later inspection.
- `gitcode-mcp` will remain a Go project using pure-Go SQLite through `modernc.org/sqlite` unless later dependency research proves otherwise.
- GitCode tracker issues and wiki pages are both required in the minimum dogfood slice.
- HTTP/SSE naming and endpoint details must be reconciled with current MCP transport terminology during reference research.
- Cross-platform credential-store support may begin with documented wrappers and environment variables before full native credential commands are complete.
- Live GitCode API validation must be optional, explicit, credential-gated, and safe to skip in CI.
- Local markdown ingest is a bridge/projection path, not the canonical source of truth.

## Runner Evidence
- Final message: `runa/calls/call-0006-run_request_formalization/attempt-1/final_message.txt`
