# Component Designs

This file is component navigation only. Use [Implementation Tasks](../implementation-tasks.md) for execution order.

- [Config & Credential](config-credential.md) (`config-credential`)
- [Repository Binding](repo-binding.md) (`repo-binding`)
- [Cache & Sync Bootstrap](cache-sync.md) (`cache-sync`)
- [GitCode Adapter](gitcode-adapter.md) (`gitcode-adapter`)
- [Index & Chunking](index-chunking.md) (`index-chunking`)
- [CLI Read Surface](cli-read.md) (`cli-read`)
- [CLI Write Surface](cli-write.md) (`cli-write`)
- [MCP Server & Transport](mcp-server.md) (`mcp-server`)
- [Snapshot & Diff](snapshot-diff.md) (`snapshot-diff`)
- [Docs & Dogfood Feedback](docs-dogfood.md) (`docs-dogfood`)
