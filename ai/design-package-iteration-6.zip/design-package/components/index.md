# Component Designs

This file is component navigation only. Use [Implementation Tasks](../implementation-tasks.md) for execution order.

- [MCP Lifecycle Surface](internal-mcp.md) (`internal-mcp`)
- [Sync Service](internal-service.md) (`internal-service`)
- [GitCode Live Adapter](internal-gitcode.md) (`internal-gitcode`)
- [Cache Layer](internal-cache.md) (`internal-cache`)
- [Credential Resolver](internal-auth.md) (`internal-auth`)
