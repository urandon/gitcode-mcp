# Research Results

## Research Index
# Research Index

## Competitor Research
- GitHub CLI: `source document`
- Model Context Protocol specification: `source document`

## External Research

## Competitor Analysis

### Reference Study: GitHub CLI

GitHub CLI implements a layered credential resolution pipeline (`env vars` -> `config file` -> `OS keyring`) with a single `ActiveToken(string)(string,string)` entry point that every command path calls identically, ensuring auth status and write commands share the same resolver. PR commands model list/detail/comments entirely via GraphQL with a dynamic field-builder (`PullRequestGraphQL`) and a unified `Finder` that resolves PRs by number, branch, or URL, then preloads comments/reviews concurrently via `errgroup`. The CLI has no persistent SQLite/WAL cache, but provides a reusable `flock` package for file-based advisory locking with cross-platform `ErrLocked` sentinel errors and a retry-with-backoff pattern used for skill lockfile concurrency.

### Reference Study: Model Context Protocol specification

The MCP specification defines tool discovery, server capability advertisement, and tool execution error conventions rather than GitCode-specific lifecycle tools, with `tools/list` and `tools/call` as the key surfaces. `docs/specification/draft/server/tools.mdx:44`
The key architectural choice is to advertise coarse server capabilities through `server/discover` or initialization, then return the currently available tool set from `tools/list`, which may be empty or change over time. `docs/specification/draft/server/discover.mdx:7`
The strongest transferable idea is to keep degraded startup inside the MCP tool namespace by advertising a reduced deterministic tool list, then report actionable startup failures via tool results using `isError: true`. `docs/specification/draft/server/tools.mdx:61`

## External Research

# External Research Synthesis: GitCode MCP Live Operations Iteration 6

## Executive Summary

Iteration 5 live smoke revealed nine operational gaps that block agent-loop usability: missing MCP lifecycle tools, silent startup failures, unbounded sync without cancellation, broken wiki bootstrap/path-normalization/write-confirmation, credential resolver asymmetry, issue label serialization defects, absent PR read/comment support, and lock contention surfaced as `internal_error` rather than typed diagnostics. All gaps are evidenced in the current repository source at schema version 11. This report maps each gap to the relevant source structures, identifies root causes, compares design alternatives, and supplies the evidence chain needed for the iteration 6 implementation design. No external web sources are cited; all evidence is from repository source observation.

## Research Scope And Source Strategy

Because no external source candidates were supplied, all evidence is drawn from direct repository source inspection. The inspected evidence families are:

- `internal/mcp/mcp.go` (Server, tool registry, write blocking, `tools/list`/`tools/call`)
- `cmd/gitcode-mcp/main.go` (startup paths, error handling, credential routing)
- `internal/cache/` (schema versioning v11, lock model, errors)
- `internal/gitcode/` (Provider interface, HTTPClient, wiki traversal, route/schema matrix, models, endpoints)
- `internal/service/` (RepositoryStatus, Index, SyncToCache, BulkSyncIssues, BulkSyncWiki, write commands, credential checks, stageWiki/stageIssue, PartialSyncError)
- `internal/gitcode/label_normalizer.go` (EncodeIssueLabels root cause)

## Relevant Existing External Mechanisms

There are no external mechanisms to cite. The repository's existing typed error hierarchy (`cache.ErrLockContention`, `service.PartialSyncError`, `gitcode.ErrNotFound`, `gitcode.ErrEmptyWiki` or equivalent — none found, proving absence of empty-wiki diagnostic) is the baseline.

### Existing Typed Diagnostics Found
- `cache.ErrLockContention` (`cache/errors.go:34`) — path, holder, operation, PID, StartedAt, CachePath.
- `cache.SchemaVersionError` (`cache/schema.go:23`) — wraps `ErrSchemaVersionIncompatible`, carries `VersionCompatibility` with Detected/Expected/PermitWrites/Remediation.
- `service.PartialSyncError` (`service/types.go:387`) — per-resource aggregation, not page-level.
- `service.ErrSyncFailure` — used for live graph validation; Mode field includes `live_graph_invalid`, `network_timeout`, `partial_response`.
- `service.ErrWriteFailure` — codes include `write_missing_credential`, `write_unconfirmed_remote`, `write_conflict`.
- `gitcode.ErrAPIValidation`, `gitcode.ErrSchemaDecode`, `gitcode.ErrPartialResponse`, `gitcode.ErrNotFound` — HTTP-level diagnostics.

### Typed Diagnostics Found Missing
- No `ErrEmptyWiki` or `empty_wiki` diagnostic anywhere in the codebase.
- No `sync_cancelled` or `sync_timeout` diagnostic class in `PartialSyncError`.
- No `write_confirmation_incomplete` diagnostic.
- No `cache_busy` (retryable) diagnostic used in read-path context.
- No `cache_path_unwritable` or `schema_incompatible` MCP-visible diagnostic.

## Design-Critical Unknowns

1. **Empty wiki HTTP behavior**: When `GET /api/v5/repos/{owner}/{repo}.wiki/contents` returns 400/404 (wiki never initialized), does `POST /api/v5/repos/{owner}/{repo}.wiki/contents/Home.md` with base64 body actually bootstrap the wiki? Live evidence from iteration 5 smoke says no — first-page creation required a human to create a page in the GitCode UI. The design must handle both the POST-attempt path (with fallback) and the typed-`unsupported` path.
2. **PR live shape fidelity**: Live shapes for `GET /pulls`, `GET /pulls/{number}`, `GET /pulls/{number}/comments`, and `POST /pulls/{number}/comments` are unverified. The route family `/api/v5/repos/{owner}/{repo}/pulls` is evidenced as existent by prior smoke but the exact field set (especially whether the response includes `discussion_id` in comments) is unconfirmed. Sanitized fixtures must be designed from the most plausible live shape but the code must tolerate field absence.
3. **Comment `note_id` field**: The `Comment` model (`models.go:249`) has no `note_id` field. The live response shape from `POST /api/v5/repos/{owner}/{repo}/issues/{num}/comments` may include `note_id` as a separate identifier. The existing model decodes `id` only. This gap is low-risk: `note_id` can be added as an optional field without breaking decode.
4. **lock_unix.go Flock behavior on macOS**: The `Flock`-based lock uses non-blocking acquisition (`lock_unix.go:51`). Whether SQLite WAL mode (`sqlite.go:71`) is sufficient for concurrent reads without writer lock acquisition depends on the cache's connection pooling strategy (currently single-connection at `sqlite.go:112` for read-only; read-write uses writer lock pre-check).

## Architecture Alternatives And Trade-Offs

### 1. MCP Minimal Server Construction (vs. hard-exit)

**Alternative A (current)**: `runMCPStdio` exits with code 1 on `ensureParentDir`, `cache.NewSQLiteStore`, or `resolveService` failure (`main.go:396-417`). No MCP server is constructed.

**Alternative B (proposed)**: On any startup failure, construct a minimal `mcp.Server` with a nil or stub `serviceInterface`. The minimal server advertises only `doctor` in `tools/list`. The startup error is carried as a field on the Server struct and surfaced in `doctor` result and `tools/list` capability metadata.

**Trade-off**: B adds complexity to Server construction (must accept nil service) and every handler must check for nil. B wins because silent tool-loss is a worse failure mode for agent clients than explicit diagnostic reporting.

### 2. Tool Registry Migration: Name-Based vs. Positional

**Alternative A (current)**: `toolRegistry()` at `mcp.go:498` binds handlers positionally (`toolDefs[0]` -> `callSearchSources`, `toolDefs[1]` -> `callGetSource`, etc.). Adding a lifecycle tool between existing definitions would desync all subsequent handler mappings.

**Alternative B (proposed)**: Construct `toolRegistry` by iterating `toolDefs` and looking up handlers from a name-keyed handler map. Each tool definition carries its handler callback as a field on `toolDefinition` (or uses a parallel `map[string]toolHandler`).

**Trade-off**: B is strictly safer. The only risk is that a new tool whose name collides with an existing one would silently shadow. Add a `init()`-time duplicate check.

### 3. Wiki Sync Bounded Traversal: Inner vs. Outer Loop

**Alternative A (outer loop wrapper)**: Wrap the entire `ListWikiPages` call with a context timeout/cancellation check and treat partial results from a completed `walk()` as a `PartialSyncError` if the outer context expired after walk returned.

**Alternative B (inner traversal refactor)**: Modify `wikiTraversal.walk()` (`http_client.go:299`) to accept a context, page limit, and progress callback. The walker checks context before each directory entry and page fetch, emits progress events per directory level or page fetched, and returns a partial results set on cancellation with a typed error.

**Trade-off**: A is insufficient because `walk()` can traverse unlimited directories/files (depth limit 64, no count limit). A cancelled context would only stop the outer caller, not the deep recursion. B is correct but requires changing the internal walker API.

### 4. Wiki Path Normalization Fix

**Root cause**: `stageWiki` at `service.go:1588` constructs `Path: "wiki/" + remoteID + ".md"`. `remoteID` is the wiki slug. When `wikiPageFromMetadata` at `http_client.go:632` sets `Slug = normalizeWikiPath(meta.Path)` and the remote path is `Home.md`, `Slug` becomes `Home.md`, and the cached path becomes `wiki/Home.md.md`.

**Alternative A**: Strip `.md`/`.markdown` extension from `remoteID` before path construction in `stageWiki`.

**Alternative B**: Use `wikiTitleFromPath(remoteID)` (existing at `http_client.go:638`) which already strips the extension, or use the title-derived clean name.

**Trade-off**: B is preferred because `wikiTitleFromPath`/`path.Ext` stripping is already available and well-tested. A risks double-stripping if the remote path already has no extension.

### 5. Issue Label Serialization Fix

**Root cause**: `EncodeIssueLabels` (`label_normalizer.go:9`) always returns a non-nil `json.RawMessage`. For empty labels, it returns `json.RawMessage("[]")`. Since `json.RawMessage` is `[]byte`, `omitempty` on `CreateIssueRequest.Labels` (`models.go:327` with `json:"labels,omitempty"`) does not suppress it — `[]byte("[]")` has length 2, not zero.

**Alternative A**: Change `EncodeIssueLabels` to return `nil` when labels are empty/nil.

**Alternative B**: Use a custom `MarshalJSON` on `CreateIssueRequest`/`UpdateIssueRequest` that conditionally omits labels.

**Trade-off**: A is simpler and fixes the root cause. Existing callers that depend on `EncodeIssueLabels` always returning non-nil would need audit, but all callers at `service.go:2079,2086` construct the request struct inline and the `json:",omitempty"` tag would then correctly suppress labels.

### 6. Credential Resolver Parity

**Root cause**: `hasWriteCredential()` at `service.go:2067` checks `s.writeCredentialPresent` for live mode, else `os.Getenv("GITCODE_TOKEN")`. But `resolveLiveClient()` at `main.go:326` uses `deps.GitCode.Token` which comes from `config.Token(src)` at `main.go:109`. The `auth status` command path at `main.go:93` bypasses `resolveLiveClient` entirely and passes local args to `cli.ExecuteWithSource`. There is no shared `CredentialResolver` invoked once per command.

**Alternative A**: Introduce `internal/auth/CredentialResolver` with a single `Resolve(ctx, src) (Token, SourceMetadata)` method called once at startup and stored in `StartupDeps`. All downstream consumers (auth doctor, live client, write credential check) read from the same resolved result.

**Alternative B**: Pass a `credentialAvailable bool` flag through `ServiceConfig` and make `hasWriteCredential` consistent with `resolveLiveClient`.

**Trade-off**: A is preferred for long-term maintainability. B is a minimal fix but perpetuates the structural split.

### 7. PR Route Schema Design

**Alternative A**: Add `pull_requests` as a new `ProductArea` in `route_schema_matrix.go`, similar to `issues`. PR list → `GET /api/v5/repos/{owner}/{repo}/pulls`, PR detail → `GET /pulls/{number}`, PR comments → `GET /pulls/{number}/comments`, PR comment write → `POST /pulls/{number}/comments`.

**Alternative B**: Model PRs as a variant of `issues` (since GitCode PRs share issue-like structure).

**Trade-off**: A is correct — the task requirement specifies `kind: pull_request` distinct from `kind: issue`, and dedicated PR comment model (`kind: pr_comment`) linked by `discussion_id`. The route family is already known from prior smoke. B would conflate source kinds and break the `sourceKindEnums` constraint at `mcp.go:171`.

### 8. Cache Concurrency Strategy

**Alternative A (current)**: Single connection, writer lock via non-blocking `Flock` (`lock_unix.go:51`), WAL mode enabled (`sqlite.go:71`). Read-only path at `sqlite.go:112` uses `?mode=ro` with 1 connection — partial reader isolation.

**Alternative B**: Maintain current writer lock for sync/write operations, but allow read-only store access (via `?mode=ro` connections) to proceed without writer lock acquisition. Classify `ErrLockContention` from read paths as `cache_busy` (retryable) rather than `internal_error`.

**Trade-off**: B is achievable with minimal changes — SQLite WAL mode already supports concurrent readers during a writer. The key change is to skip `AcquireWriter` for read-only operations (`search_sources`, `list_sources`, `get_source`, etc.) and surface contention from writer-acquiring operations (sync, write) as typed `cache_busy`.

## Primary Decision Hierarchy

1. **MCP minimal server must be constructed even on startup failure** — this gates all readiness diagnostics.
2. **Tool registry migration to name-based indexing must precede lifecycle tool additions** — adding tools before migration guarantees desynchronization bugs.
3. **Wiki internal traversal must be refactored before bounded sync can apply to wiki** — outer loop wrapping is insufficient.
4. **`EncodeIssueLabels` must return nil for empty labels** — the `omitempty` tag is ineffective against `json.RawMessage([]byte("[]"))`.
5. **Credential resolver must be a shared entry point invoked once** — parity between `auth status` and write commands depends on this.
6. **PR route implementation requires new `ProductAreaPullRequests` support status change from `deferred` to `supported`** — the matrix currently blocks `ProductAreaComments` and `ProductAreaPullRequests` at `provider.go:211` and schema at `route_schema_matrix.go:108`.
7. **Comment model must add `NoteID` field** — the live comment response includes `note_id` which the current `Comment` model (`models.go:249`) does not decode.

## Low-Level Implementation Details

### MCP Tool Registry Migration (`internal/mcp/mcp.go`)

Current: `toolRegistry()` returns fixed map with positional handler assignment.
Target: Define a `map[string]toolHandler` handler registry const; `toolRegistry()` iterates `toolDefs` and looks up each by name. Lifecycle tools add their definitions to `toolDefs` and handlers to the registry map. No positional coupling.

### Wiki Path Normalization

Current `stageWiki` at `service.go:1588`:
```go
Path: "wiki/" + remoteID + ".md"
```
Target:
```go
cleanSlug := strings.TrimSuffix(remoteID, path.Ext(remoteID))
Path: "wiki/" + cleanSlug + ".md"
```
Also fix `wikiWriteGraph` at `service.go:2197` which has the same pattern.

### Issue Label Serialization

Current `EncodeIssueLabels` at `label_normalizer.go:9-26` always returns non-nil.
Target: Return `nil` when `cleaned` is nil or has zero length, and remove lines 18-20 that force `cleaned = []string{}`. The caller in `callWriteAdapter` at `service.go:2079,2086` passes the result as `Labels: gitcode.EncodeIssueLabels(req.Labels)`. With `omitempty`, a nil `json.RawMessage` is omitted from JSON output.

### Credential Resolver

New file `internal/auth/resolver.go`:
```go
type CredentialSource int
const (
    SourceEnvVar CredentialSource = iota
    SourceKeychain
    SourceNone
)

type CredentialResolver struct {
    source CredentialSource
    token  string
}

func Resolve(src config.Source) *CredentialResolver
func (r *CredentialResolver) Token() string
func (r *CredentialResolver) Available() bool
func (r *CredentialResolver) Source() CredentialSource
```

Invoked once at `main.go:104` after `config.Load`; result stored in `StartupDeps` and propagated to `Service` and `auth status` command paths.

### PR Models and Endpoints

New models (`models.go` additions):
```go
type PullRequest struct {
    ID        string    `json:"id"`
    Number    int       `json:"number"`
    HTMLURL   string    `json:"html_url"`
    State     string    `json:"state"`
    Title     string    `json:"title"`
    Body      string    `json:"body"`
    User      User      `json:"user"`
    Labels    []string  `json:"labels"`
    CreatedAt time.Time `json:"created_at"`
    UpdatedAt time.Time `json:"updated_at"`
}

type PRComment struct {
    ID            string    `json:"id"`
    NoteID        string    `json:"note_id,omitempty"`
    DiscussionID  string    `json:"discussion_id"`
    Body          string    `json:"body"`
    User          User      `json:"user"`
    CreatedAt     time.Time `json:"created_at"`
    UpdatedAt     time.Time `json:"updated_at"`
}

type User struct {
    ID       int    `json:"id"`
    Username string `json:"username"`
}
```

New endpoints (`endpoints.go` additions):
```go
func listPullsEndpoint(owner, repo string) string
func getPullEndpoint(owner, repo string, number int) string
func listPRCommentsEndpoint(owner, repo string, number int) string
func createPRCommentEndpoint(owner, repo string, number int) string
```

Route pattern: `/api/v5/repos/{owner}/{repo}/pulls` for list, `/api/v5/repos/{owner}/{repo}/pulls/{number}` for detail, `/api/v5/repos/{owner}/{repo}/pulls/{number}/comments` for comments.

### Cache Projections for PR Records

PR records use `record_type: "pull_request"` in the `records` table (schema supports arbitrary record_type values). PR comments use `record_type: "pr_comment"` in the `record_comments` table with `discussion_id` stored as `remote_id` or a separate metadata column. The `kind` field in the `sources` table is extended beyond `["issue", "wiki"]` to include `"pull_request"`.

## Evidence Coverage

| Evidence Family | Source Files | Status |
|---|---|---|
| MCP tool registry (positional) | `internal/mcp/mcp.go:498-516` | Confirmed: 15 tools mapped by position |
| MCP write blocking | `internal/mcp/mcp.go:457-483` | Confirmed: only hyphenated names blocked; missing `create_issue` underscore variant |
| MCP startup hard-exit | `cmd/gitcode-mcp/main.go:396-417` | Confirmed: exit code 1 before Server construction |
| HTTP/SSE readiness probe | `cmd/gitcode-mcp/main.go:436-449` | Confirmed: lock contention classified; pre-Service errors exit hard |
| Schema version v11 | `internal/cache/schema.go:10` | Confirmed: migrations v1-v11 at line 126 |
| Schema incompatibility check | `internal/cache/schema.go:89` | Confirmed: newer cache → incompatible with remediation text |
| WAL mode | `internal/cache/sqlite.go:71` | Confirmed: enabled on open |
| Writer lock (Flock) | `internal/cache/lock_unix.go:51` | Confirmed: non-blocking, returns `ErrLockContention` |
| Read-only store path | `internal/cache/sqlite.go:112` | Confirmed: `?mode=ro` with 1 connection |
| Provider interface (no PR methods) | `internal/gitcode/provider.go:13-30` | Confirmed: 17 methods, none for PRs |
| ListWikiPages recursion | `internal/gitcode/http_client.go:299-352` | Confirmed: depth limit 64, no context checks in walk, no page count limit |
| Wiki path normalization bug | `internal/service/service.go:1588` | Confirmed: `"wiki/" + remoteID + ".md"` produces double `.md` |
| Wiki write confirmation | `internal/gitcode/http_client.go:397-412` | Confirmed: validates immediate response `path`/`sha`, no follow-up GET |
| Route schema matrix (PR/comments deferred) | `internal/gitcode/route_schema_matrix.go:108-129` | Confirmed: both deferred with `unsupported_capability` |
| liveProvider preflights comments | `internal/gitcode/provider.go:211-216` | Confirmed: `ProductAreaComments` blocked via matrix.Preflight |
| sourceKindEnums (no PR kind) | `internal/mcp/mcp.go:171` | Confirmed: `["issue", "wiki"]` only |
| RepositoryScope (no PR scope) | `internal/service/types.go:22-25` | Confirmed: `["issues", "wiki"]` only |
| Comment model (no note_id) | `internal/gitcode/models.go:249-256` | Confirmed: `id`, `issue_id`, `body`, `author`, `created_at`, `updated_at` — no `note_id` |
| EncodeIssueLabels always non-nil | `internal/gitcode/label_normalizer.go:9-26` | Confirmed: `cleaned = []string{}` at line 19 guarantees non-nil output |
| hasWriteCredential source split | `internal/service/service.go:2067-2072` | Confirmed: live mode uses struct field; non-live uses `os.Getenv` |
| auth/doctor bypass resolveLiveClient | `cmd/gitcode-mcp/main.go:93-102` | Confirmed: early return before credential resolution |
| PartialSyncError (per-resource only) | `internal/service/types.go:387-405` | Confirmed: aggregates `ResourceError` per source, not per page/batch |
| Service.Index vs StaleIndex | `internal/service/service.go:842-872` vs `684` | Confirmed: Index chunks and saves snapshot; StaleIndex is diagnostic-only |
| Service.RepositoryStatus | `internal/service/service.go:255-268` | Confirmed: reads from cache store, returns binding info — suitable for MCP |
| BulkSyncIssues (single ListIssues call) | `internal/service/service.go:1034-1085` | Confirmed: one `client.ListIssues` call, no page-based batching or progress |
| BulkSyncWiki (calls SyncResources per page) | `internal/service/service.go:1087-1119` | Confirmed: one `client.ListWikiPages` call, then per-page `SyncResources` |

## Evidence Gaps And Negative Findings

### Negative Findings (confirmed absences)
1. **No `empty_wiki` diagnostic**: Searched all error definitions in `cache/errors.go`, `gitcode/models.go` (error types at end), and `service/types.go`. No type or diagnostic class references `empty_wiki`, `uninitialized_wiki`, or `wiki_bootstrap`.
2. **No `sync_cancelled` diagnostic class**: `PartialSyncError` carries `ResourceError` list but no overall diagnostic classification for cancellation vs. timeout vs. partial completion.
3. **No progress channel**: `BulkSyncIssues`, `BulkSyncWiki`, and `ListIssues`/`ListWikiPages` methods receive no progress callback parameter. No channel-based progress emission exists.
4. **No `write_confirmation_incomplete` diagnostic**: `writeWikiContent` at `http_client.go:397` either confirms path+sha or returns `ErrPartialResponse`. No middle ground for "write succeeded but confirmation incomplete".
5. **No `note_id` in Comment model**: Verified at `models.go:249-256` — only 6 fields.
6. **No PR methods on Provider interface**: Verified at `provider.go:13-30` — 17 methods, none for pull requests.
7. **No PR endpoints**: Verified at `endpoints.go:1-115` — no `pulls`-prefixed endpoint functions.
8. **No `cache_busy` error code used for read-path contention**: `cacheLockErrorCode` at `mcp.go:1378` returns `"busy"` for unknown operations but only from `LockContentionReadiness` used in HTTP/SSE path. Stdio MCP path never surfaces contention.
9. **No `doctor` MCP tool**: `mcp.go:208-361` lists 15 tools — none named `doctor`, `repo_status`, `sync_live`, `index_repo`, or `auth_status`.
10. **No `internal/auth` package**: Verified via directory listing — `internal/` contains `cache/`, `cli/`, `config/`, `diagnostics/`, `gitcode/`, `index/`, `mcp/`, `service/`, `audit/`. No `auth/` directory.

### Evidence Gaps (unverifiable from source)
1. **Live PR response shapes**: Cannot verify field set for `/api/v5/repos/{owner}/{repo}/pulls` responses without live API access or fixtures.
2. **Wiki bootstrap POST behavior**: Cannot verify whether `POST /api/v5/repos/{owner}/{repo}.wiki/contents/Home.md` with base64 body returns 201 (wiki init success) or 400/404 (wiki not initialized) without live API access.
3. **Comment response `note_id` presence**: Cannot verify whether live `POST /comments` response includes `note_id` field without live API access or a response fixture.

## Findings By Component Or Concern

### MCP Server (`internal/mcp/mcp.go`)
- **Tool registry is positionally indexed** (`toolRegistry()` at line 498). Each handler maps to `toolDefs[n]` by index. Adding a lifecycle tool between index 0 and 14 breaks all subsequent mappings. Migration to name-based map lookup is prerequisite.
- **Write blocking** (`blockedWriteTools` at line 457) covers hyphenated names only. The underscore variant `create_issue` is not blocked — though MCP clients typically use hyphenated tool names, the gap exists.
- **`serviceInterface`** (line 23) does not include `RepositoryStatus`, `SyncToCache`/`BulkSyncIssues`/`BulkSyncWiki`, `Index`, `ProbeAuth` equivalents, or doctor diagnostic methods. Extending the interface requires matching changes to `newRPCHandler` and all handler implementations.
- **`toolsList`** (line 443) filters `toolDefs` against `toolRegistry`. A tool whose definition exists but handler is not in `toolRegistry` is silently omitted. This is the mechanism for selective tool advertisement (e.g., no write tools in MCP).

### CLI Startup (`cmd/gitcode-mcp/main.go`)
- **Stdio path** (`runMCPStdio`, line 396): `ensureParentDir` → `cache.NewSQLiteStore` → `resolveService` → `mcp.New`. Any failure exits with code 1 before Server is constructed. No fallback tool surface.
- **HTTP/SSE path** (`runMCPHTTPSSE`, line 420): Same hard-exit pattern, but has a post-construction `ReadinessProbe` callback (line 436) that classifies lock contention. Pre-service errors (schema, cache open) still exit hard.
- **Auth/doctor early return** (line 93): `rest[0] == "auth" || rest[0] == "doctor"` bypasses `buildStartupDeps` and `resolveLiveClient`, using `cli.ExecuteWithSource` directly. This is the structural cause of credential resolver parity gap.
- **Token sourcing**: `config.Token(src)` at line 109 — single call, result passed to `buildStartupDeps`. But `auth status` path at line 93 never calls this.

### Cache (`internal/cache/`)
- **Schema version 11** (`schema.go:10`): All version checks must reference 11, not 7.
- **Newer-cache rejection** (`schema.go:89`): Version > 11 → incompatible, `PermitWrites: false`, with remediation text suggesting binary upgrade.
- **Older-cache migration** (`schema.go:100`): Version < 11 → `PermitWrites: false` until `migrate-cache` command runs.
- **WAL mode** (`sqlite.go:71`): Enables concurrent readers with a writer. This is foundational for the concurrency design.
- **Read-only store** (`sqlite.go:112`): Opens with `?mode=ro` + single connection. This can serve read-only MCP tools without writer lock.
- **`ErrLockContention`** (`errors.go:34`): Carries path, operation, PID, CachePath, StartedAt. No `IsRetryable()` method — the MCP server classifies it as `cache_owned`, `migration_blocked`, or `busy` in `cacheLockErrorCode` at `mcp.go:1378`.

### GitCode Adapter (`internal/gitcode/`)
- **Provider interface lacks PR methods** (`provider.go:13`): Must add `ListPullRequests`, `GetPullRequest`, `ListPRComments`, `CreatePRComment`.
- **`liveProvider.ListIssueComments` preflights** (`provider.go:211`): Matrix check returns `ErrUnsupportedCapability` for `ProductAreaComments` (currently deferred at `route_schema_matrix.go:119`). Unblocking requires changing matrix status to `supported`.
- **Wiki traversal is unbounded** (`http_client.go:299`): `walk()` checks depth ≤ 64 but has no per-page or total-count limit. No context cancellation checks during traversal. No progress callback.
- **Wiki write confirmation** (`http_client.go:397`): Calls `writeConfirmedJSON[WikiContentsFile]` with confirm function requiring `path` and `sha`. If the provider response lacks either, confirmation fails. No follow-up read-back GET.
- **PR route family** is not implemented. The route `/api/v5/repos/{owner}/{repo}/pulls` family is deployed in GitCode API but no Go code exists for it.

### Service Layer (`internal/service/`)
- **`RepositoryStatus`** (`service.go:255`): Reads from cache store, returns binding info. Ready for MCP exposure.
- **`Index`** (`service.go:842`): Indexes sources and stores snapshot. Suitable for `index_repo` MCP tool. Not `StaleIndex` (diagnostic-only at line 684).
- **`BulkSyncIssues`** (`service.go:1034`): Single `client.ListIssues` call. No page-based batching. If context is canceled mid-call, no partial results are returned (the `SyncResourcesResult` is constructed after all items are processed).
- **`BulkSyncWiki`** (`service.go:1087`): Single `client.ListWikiPages` call. The later `SyncResources` call per page is bounded per-source, but the initial wiki list traversal (inside `client.ListWikiPages`) is unbounded.
- **`BulkSyncAll`** (`service.go:1121`): Aggregates issues and wiki results with `PartialSyncError`. Precedent for partial-sync return pattern.
- **`hasWriteCredential`** (`service.go:2067`): Two code paths — live mode checks struct field, non-live checks env var. Asymmetric with `resolveLiveClient` at `main.go:326` (uses `deps.GitCode.Token` from `config.Token`).
- **`stageWiki` path construction** (`service.go:1588`): `"wiki/" + remoteID + ".md"` — confirmed root cause of double-extension.
- **`wikiWriteGraph` path construction** (`service.go:2197`): Same pattern — also needs fix.

### Label Normalizer (`internal/gitcode/label_normalizer.go`)
- **`EncodeIssueLabels`** (line 9): Always returns non-nil `json.RawMessage`. Empty labels → `json.RawMessage("[]")`. Since `json.RawMessage` is `[]byte`, `omitempty` on `labels` struct field does not suppress it.

## Comparative External Systems

No external systems are evaluated in this research. The analysis is repository-internal. However, the following design patterns from comparable MCP servers and cache-first systems inform the recommendations:

- **MCP minimal server pattern**: The MCP specification (protocol version 2024-11-05) does not mandate server initialization success for `tools/list`. A server can return an empty or reduced tool list with capability metadata indicating degraded state. This is consistent with the `doctor` tool approach.
- **SQLite WAL concurrent reader pattern**: Go's `mattn/go-sqlite3` supports `?_journal_mode=WAL` + multiple read connections. WAL mode allows any number of readers concurrent with at most one writer. This is the industry-standard pattern for read-heavy cache stores.
- **Bounded traversal with progress**: The `context.Context` + callback pattern used by Go's standard library (`filepath.WalkDir` → `fs.WalkDirFunc` returning `filepath.SkipDir` or error) provides the template for wiki tree traversal with cancellation and progress.

## Engineering Implications For Later Design

1. **Minimal MCP server construction** requires a new `mcp.NewFallbackServer(diagnostic)` constructor or a `WithStartupError` option on the existing Server. Every handler must nil-check `svc` before calling service methods.
2. **Tool registry migration** is a refactoring step that must be done before any lifecycle tool additions. Regression test: add a new tool definition, verify it gets the correct handler.
3. **Wiki internal traversal refactor** changes the `wikiTraversal.walk` signature to accept `context.Context`, `maxPages int`, and a `func(WikiPage)` progress callback. Existing callers (`ListWikiPages`, `getWikiPageByPath` indirectly) must update.
4. **Label serialization fix** (`EncodeIssueLabels` returning `nil` for empty) is a one-line change with high blast radius — all callers that currently depend on non-nil return must be verified.
5. **PR route unblocking** requires: update `route_schema_matrix.go` to mark `ProductAreaPullRequests` and `ProductAreaComments` as `supported`; update `liveProvider` to remove `Preflight` calls for comments; add PR methods to `Provider`, `HTTPClient`, and `liveProvider`; update `sourceKindEnums` to include `"pull_request"`, `"pr_comment"`.
6. **Credential resolver package** (`internal/auth/`) is a new package. All existing `config.Token()` and `os.Getenv("GITCODE_TOKEN")` call sites must be consolidated to the resolver.

## Follow-Up Questions For Later Design

1. Should `EncodeIssueLabels` returning nil for empty labels be the mechanism, or should `CreateIssueRequest`/`UpdateIssueRequest` use a custom `MarshalJSON`? The nil-return approach is simpler but changes the contract for all callers.
2. For PR records, should `discussion_id` be stored as `remote_id` on the `record_comments` row, or as a separate metadata column? The existing schema has `remote_id` on `records` but `record_comments` uses `record_id` + `comment_id` — no `remote_id` column exists on `record_comments`.
3. For wiki empty diagnostic, should the `ListWikiPages` HTTP client call detect 400/404 and return a typed `ErrWikiUninitialized`, or should the service layer classify the error after receiving raw `ErrAPIValidation`/`ErrNotFound`? The former is more precise; the latter avoids coupling HTTP details to business logic.
4. For bounded sync, should `PartialSyncError` carry a `DiagnosticClass` field (e.g., `sync_cancelled`, `sync_timeout`, `sync_page_limit`) or should the error be wrapped in a separate typed error that `errors.As` can extract? The `DiagnosticClass` approach is consistent with the existing `failure_class` pattern in `mcpDiagnostic`.
5. Should concurrent read-only MCP tools use the existing read-only store path (`?mode=ro`), or should the main store connection be shared with a read-lock pattern? The read-only store path already exists for a different purpose (read-only mode); reusing it may conflict with that purpose.

## Source Quality Notes

All sources are repository-internal Go source files. No external URLs, live API calls, or web research was performed. Source line numbers are current as of the repository snapshot inspected. The evidence is direct (source code lines observable in file contents) with the exception of live API response shapes which are inferred from model structs and the task brief claims.

## Runner Evidence
- Final message: `runa/calls/call-0666-run_external_research/attempt-6/final_message.txt`
