# Research Results

## Research Index
# Research Index

## Competitor Research
- GitHub CLI: `source document`

## External Research

## Competitor Analysis

### Reference Study: GitHub CLI

GitHub CLI demonstrates a mature Go CLI API modeling pattern where issues, labels, milestones, PRs, and comments all share a unified `Editable` struct with discrete add/remove label mutations, and errors are strictly classified into typed categories (`FlagError`, `HTTPError`, `NoResultsError`) rather than collapsed into a single transport bucket. The strongest transferable idea is the label add/remove-as-discrete-mutations pattern executed via `addLabelsToLabelable` and `removeLabelsFromLabelable` GraphQL calls rather than a replacement-style endpoint, which GitCode MCP should adapt for its add-label behavior to avoid JSON array regressions.

## External Research

# Executive Summary

- No source-backed external research synthesis can be produced from the provided evidence set because `Curated Source Candidates` is empty, `Component Evidence` is `{}`, and live web search is prohibited.
- The only defensible finding is negative: no concrete external mechanisms, comparative systems, API routes, schemas, or behavior claims can be cited under the required citation rules.
- Later design should not treat any route, schema, wiki behavior, label payload form, or error-classification behavior as externally validated by this research artifact.

# Research Scope And Source Strategy

- Scope requested: external research synthesis for GitCode MCP live API coverage iteration 5, covering Issues, Labels, Milestones, Pull Requests, Comments, Wiki, errors, cache provenance, and MCP write exposure.
- Source strategy actually available:
  - Use provided component evidence and synthesis as primary evidence.
  - Do not inspect the local target repository.
  - Do not perform live web search.
- Result: no usable external source candidates were available, so no concrete external claims are made.

# Relevant Existing External Mechanisms

No source-backed external mechanisms can be reported.

| Mechanism area | Evidence status | Finding |
|---|---:|---|
| GitCode `/api/v5` issues | Missing | No cited external source available. |
| GitCode label create/update payloads | Missing | No cited external source available. |
| GitCode label response objects | Missing | No cited external source available. |
| Milestones | Missing | No cited external source available. |
| Pull requests | Missing | No cited external source available. |
| Comments | Missing | No cited external source available. |
| Wiki-as-repository contents/raw APIs | Missing | No cited external source available. |
| Browser `web-api` wiki routes | Missing | No cited external source available. |
| Error taxonomy patterns | Missing | No cited external source available. |
| Cache provenance/isolation precedents | Missing | No cited external source available. |
| MCP write exposure precedents | Missing | No cited external source available. |

# Design-Critical Unknowns

- Whether the documented GitCode `/api/v5` surfaces are stable enough for production adapter behavior.
- Whether issue identity fields are consistently numeric/string across list, create, update, and detail routes.
- Whether labels must always be encoded as a JSON string in issue mutation payloads.
- Whether add-label behavior should be modeled as issue update, a dedicated endpoint, or unsupported.
- Whether milestone, PR, and comment routes have response shapes compatible with cache normalization.
- Whether wiki CRUD through `{repo}.wiki` repository contents APIs is stable and token-compatible.
- Whether browser `web-api` wiki routes have any public-safe, non-cookie credential path.
- Which error bodies distinguish API validation, schema mismatch, decode failure, credential failure, and transport failure.
- How fixture and live cache records should expose provenance or isolation.
- Whether MCP write tools are appropriate for this iteration.

# Architecture Alternatives And Trade-Offs

| Alternative | Potential benefit | Failure mode | Evidence status |
|---|---|---|---:|
| Implement all surfaces from candidate `/api/v5` routes | Broad live coverage | Schema drift or route mismatch without verified sources | Unsupported by evidence |
| Implement only Issues, Labels, Wiki; defer Milestones/PRs/Comments | Lower risk, focused coverage | Leaves coverage gaps requiring explicit diagnostics | Unsupported by evidence |
| Treat add-label as issue update | Avoids possibly invalid dedicated route | May overwrite labels if merge semantics are wrong | Unsupported by evidence |
| Remove/deprecate add-label route | Prevents false endpoint assumptions | Reduces CLI ergonomics | Unsupported by evidence |
| Wiki via `/api/v5/repos/{owner}/{repo}.wiki/contents|raw` | Token-compatible if true | Undocumented behavior may change | Unsupported by evidence |
| Wiki via browser `web-api` routes | May match UI behavior | Cookie/session dependence, public-safety concerns | Unsupported by evidence |
| MCP read-only in this slice | Lower write-risk and simpler idempotency | Users need CLI for mutations | Unsupported by evidence |
| MCP write tools in this slice | More complete MCP surface | Requires stronger idempotency, diagnostics, and safety gates | Unsupported by evidence |

# Primary Decision Hierarchy

Because no external evidence is available, later design should use this decision hierarchy only as a research-gap framing, not as a final recommendation:

1. Prefer behaviors backed by official public API documentation or sanitized live probes.
2. Prefer token-compatible `/api/v5` routes over browser-session or cookie-dependent routes.
3. Prefer explicit unsupported diagnostics over silent empty-cache success.
4. Prefer mocked offline tests for every accepted or deferred product surface.
5. Prefer CLI mutation support before MCP write exposure unless idempotency and diagnostics are proven.
6. Prefer cache provenance/isolation over implicit namespace reuse between fixture and live data.

# Low-Level Implementation Details

No low-level external implementation details are source-backed in this evidence set.

Details requiring later evidence before design use:

- Exact issue identity normalization rules for `id`, `number`, and stable source identifiers.
- Exact label request encoding and response normalization.
- Exact milestone route names and response schemas.
- Exact PR and comment route names and response schemas.
- Exact wiki path encoding, base64 content handling, `sha` update/delete semantics, and raw decoding behavior.
- Exact error body patterns for 400, malformed JSON, schema mismatch, auth/config, and transport failures.
- Exact cache provenance fields, reset semantics, or namespace separation model.
- Exact MCP unsupported-capability response shape.

# Evidence Coverage

| Concern | Direct evidence | Inference | Negative finding |
|---|---:|---:|---|
| Issues | None | None | Cannot validate route/schema. |
| Labels | None | None | Cannot validate payload or object shape. |
| Add-label behavior | None | None | Cannot validate endpoint or update-based substitute. |
| Milestones | None | None | Cannot validate implementation or deferral rationale externally. |
| Pull requests | None | None | Cannot validate route/schema. |
| Comments | None | None | Cannot validate route/schema. |
| Wiki | None | None | Cannot validate `/api/v5` wiki-as-repository or browser `web-api`. |
| Error classification | None | None | Cannot validate body/status taxonomy. |
| Cache provenance | None | None | Cannot cite external precedent. |
| MCP writes | None | None | Cannot cite external precedent. |
| Offline validation | None | None | Cannot cite external precedent. |
| Live smoke gates | None | None | Cannot cite external precedent. |

# Evidence Gaps And Negative Findings

- No official GitCode API references were supplied.
- No OpenAPI excerpts were supplied.
- No sanitized live probe transcripts were supplied as citable source artifacts.
- No repository-derived component evidence was supplied.
- No comparative external systems were supplied.
- No source IDs exist, so no concrete external claim can be cited.
- The provided component synthesis explicitly states that no usable component candidates, source traceability, repository-derived mechanisms, official API references, or sanitized live probes were available.

# Findings By Component Or Concern

## Issues

- Evidence-backed finding: none.
- Design risk: GitHub-like identity assumptions may be wrong, but this cannot be externally confirmed from available sources.

## Labels

- Evidence-backed finding: none.
- Design risk: payload encoding and response shape are central regression points, but no citable external source is available.

## Milestones

- Evidence-backed finding: none.
- Design risk: implementing from assumption could misclassify unsupported routes as empty cache or transport failure.

## Pull Requests And Comments

- Evidence-backed finding: none.
- Design risk: route and schema ambiguity requires explicit defer-or-implement tests later.

## Wiki

- Evidence-backed finding: none.
- Design risk: product behavior, `/api/v5` repository contents behavior, browser `web-api`, and credential models cannot be validated here.

## Error Classification

- Evidence-backed finding: none.
- Design risk: 400/schema/decode errors should be distinguished from transport failures, but exact external error shapes are unknown.

## Cache Provenance

- Evidence-backed finding: none.
- Design risk: fixture/live namespace collisions require a local design decision and tests, not external claims from this artifact.

## MCP Write Exposure

- Evidence-backed finding: none.
- Design risk: write exposure should be gated by idempotency, diagnostics, and credential safety decisions established elsewhere.

# Comparative External Systems

No comparative external systems can be cited because no source candidates were provided and live web search is prohibited.

# Engineering Implications For Later Design

- Treat this artifact as an evidence-gap report, not a design authority.
- Later design should source claims from official API docs, sanitized live probes, or mocked fixtures derived from validated probes.
- Every accepted route should have offline mocked tests that exercise parsing, normalization, cache exposure, and diagnostics.
- Every deferred route should have explicit unsupported diagnostics tested through CLI or MCP paths.
- Avoid browser-cookie or browser-session credential paths unless separately validated and approved.
- Keep optional live smoke credential-gated, redacted, and skipped by default.

# Follow-Up Questions For Later Design

1. Which official GitCode API documentation pages are citable for issues, labels, milestones, PRs, comments, and repository contents?
2. Which sanitized live probe artifacts can be cited for issue identity shapes and label payload behavior?
3. Is `/api/v5/repos/{owner}/{repo}.wiki/contents|raw` documented, or only live-probe validated?
4. What are the exact GitCode error bodies for validation errors, auth failures, missing resources, and malformed responses?
5. Should add-label merge existing labels through issue update, or be removed/deprecated?
6. Should MCP writes remain absent for iteration 5, or should a narrow idempotent subset be exposed?
7. What cache provenance field or namespace boundary best prevents fixture/live confusion?

# Source Quality Notes

- Source availability: none.
- Citation completeness: no citations are present because no sources exist.
- Freshness risk: unassessable.
- Authority: unassessable.
- Implementation value: limited to documenting absence of evidence and preventing unsupported external claims.

## Runner Evidence
- Final message: `runa/calls/call-0034-run_external_research/attempt-1/final_message.txt`
