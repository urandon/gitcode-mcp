# Component Designs

This file is component navigation only. Use [Implementation Tasks](../implementation-tasks.md) for execution order.

- [RouteSchemaMatrix](route-schema-matrix.md) (`route-schema-matrix`)
- [Label Normalizer](label-normalizer.md) (`label-normalizer`)
- [Issue Normalizer](issue-normalizer.md) (`issue-normalizer`)
- [Wiki Provider](wiki-provider.md) (`wiki-provider`)
- [Error Classifier](error-classifier.md) (`error-classifier`)
- [Cache Provenance Layer](cache-provenance-layer.md) (`cache-provenance-layer`)
- [MCP Server Write Boundary](mcp-server-write-boundary.md) (`mcp-server-write-boundary`)
- [Live Adapter PR/Comment Deferral](live-adapter-pr-comment-deferral.md) (`live-adapter-pr-comment-deferral`)
- [Milestone Adapter](milestone-adapter.md) (`milestone-adapter`)
- [CLI Label Mutation Commands](cli-label-mutation-commands.md) (`cli-label-mutation-commands`)
