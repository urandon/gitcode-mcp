# Request Formalization Revision 1

## Main user request information
Design GitCode MCP live API coverage iteration 5 for the Go target repository `/Users/urandon/workspace/ai-processing/gitcode-mcp`. The goal is to close live API coverage and schema gaps found during iteration 4 polygon smoke testing, not to repeat provider wiring. Scope includes live adapter route/schema decisions for Issues, Labels, Milestones, Pull Requests, Comments, and Wiki; GitCode-shaped label modeling; add-label behavior; wiki route strategy; error classification; cache provenance or isolation; and MCP write exposure. Constraints include public-safe artifacts, credential-gated live smoke only, no browser-cookie credential storage, deterministic offline validation, and `go test ./...` passing without network, credentials, SSH agent, or OS Keychain. Affected components likely include live GitCode adapter models, CLI issue/label commands, MCP read tools, cache schema/sync paths, error taxonomy, fixture/live test boundaries, docs/runbooks, and optional live smoke scripts.

## Decomposed tasks
### Task 1: Define route schema matrix
Description: Specify the live route and schema coverage contract for Issues, Labels, Milestones, Pull Requests, Comments, and Wiki with evidence class OpenAPI, live probe, or deferred.
Acceptance Criteria: Developer triggers the offline Go test suite for the target runtime using `go test ./...`; adapter-level tests exercise each selected or deferred product surface and prove that Issues, Labels, Milestones, Pull Requests, Comments, and Wiki either parse GitCode-shaped responses through target code paths or return the intended unsupported diagnostic rather than relying on a document-only matrix.

### Task 2: Normalize issue identity shapes
Description: Capture GitCode issue response tolerance for numeric `id` and string `number`, and normalize these values into stable cache/source identifiers without GitHub-only assumptions.
Acceptance Criteria: Sync actor runs mocked live issue read tests against the target GitCode provider route `/api/v5/repos/{owner}/{repo}/issues`; responses containing numeric `id` and string `number` are accepted, cached, and exposed through CLI or MCP cache reads with stable source identifiers, while malformed identity fields produce a classified schema diagnostic.

### Task 3: Model labels and add-label behavior
Description: Specify GitCode label create/update payloads as JSON-string label lists, parse returned label objects with `id`, `name`, `color`, `created_at`, and `updated_at`, and decide whether the existing add-label route is corrected, removed/deprecated, or implemented through issue update.
Acceptance Criteria: Operator triggers target CLI issue create/update/add-label flows against stubbed GitCode live routes; outgoing issue mutation payloads encode labels in the GitCode-accepted JSON string form, incoming label objects normalize into cache source labels, JSON array label payload regressions fail tests, and the old `/api/v5/repos/{owner}/{repo}/issues/{number}/labels` assumption is either absent from product execution or returns the designed diagnostic.

### Task 4: Decide milestone coverage
Description: Specify milestone adapter/cache behavior using documented `/api/v5` milestone surfaces, or explicitly defer milestones with operator-facing diagnostics and follow-up scope.
Acceptance Criteria: User triggers the target CLI or MCP read/sync surface for milestone-related issue data; implemented milestone responses are parsed and cached through tested adapter paths, or deferred milestone access returns a clear unsupported capability diagnostic with no network-shape misclassification, proven by `go test ./...` using mocked GitCode responses.

### Task 5: Decide PR and comment coverage
Description: Specify Pull Request and comment adapter/cache behavior using documented or expected surfaces, or explicitly defer them with operator-facing diagnostics and follow-up scope.
Acceptance Criteria: User triggers target MCP or CLI read/sync surfaces for Pull Requests and comments; implemented routes produce cached readable records through target runtime tests, or deferred routes return explicit unsupported capability diagnostics, with mocked external GitCode responses proving no silent empty-cache success and no transport-failure misclassification.

### Task 6: Select wiki provider strategy
Description: Prefer token-compatible `/api/v5/repos/{owner}/{repo}.wiki/contents` and `/raw` wiki-as-repository behavior for read/list/write design, keep browser `web-api` routes out of product use unless a stable non-cookie credential path is proven, and define unsupported diagnostics if wiki write/sync is not included.
Acceptance Criteria: Wiki actor triggers target sync/read and any exposed write path through the GitCode provider; tests exercise traversal, path encoding, markdown/raw decoding, base64 create/update content, current `sha` update/delete semantics, and error handling on `/api/v5/repos/{owner}/{repo}.wiki`, while browser `web-api.gitcode.com/api/v2/projects/wiki/*` routes are not used by default product execution without a credential-gated validation.

### Task 7: Redesign error classification
Description: Specify classification for 400 responses, malformed JSON, schema mismatches, partial response diagnostics, credential/configuration failures, and true transport failures.
Acceptance Criteria: Operator triggers CLI and MCP paths backed by mocked GitCode 400 responses, malformed JSON, schema mismatch bodies, credential failures, and network failures; the target runtime reports schema/decode/API validation classes distinctly from `live_transport_failure` and configuration failure, and regression tests fail if 400/schema/decode errors are reported as network outages.

### Task 8: Separate cache provenance
Description: Specify cache provenance or live-cache reset/isolation behavior so fixture records and live polygon records cannot be confused inside one repository namespace.
Acceptance Criteria: User runs target sync/cache commands across fixture-mode and live-mode inputs; cache reads expose provenance or isolation state, fixture-to-live transitions are deterministic, and a tested reset/isolation command or state contract prevents stale fixture records from masquerading as live GitCode data.

### Task 9: Decide MCP write exposure
Description: Decide whether MCP exposes issue create/update/label and wiki writes in this slice, or remains read/cache oriented while CLI remains the supported mutation surface.
Acceptance Criteria: MCP client triggers advertised target MCP tools; write tools are either present with tested idempotent mutation behavior and sanitized diagnostics, or absent/read-only with CLI mutation commands still functioning under tests and MCP returning a clear unsupported capability response for write attempts.

### Task 10: Define validation and smoke gates
Description: Define offline validation and optional credential-gated live smoke expectations for iteration 5 without requiring real credentials, network, SSH agent, or OS Keychain in normal tests.
Acceptance Criteria: Developer runs `go test ./...` and `git diff --check` locally without credentials, network, SSH agent, or OS Keychain and the target suite passes; optional live smoke commands are separately gated, redacted, and skip safely when credentials or polygon coordinates are unavailable.

## Assumptions
- The formalization stage does not inspect the target repository; implementation details must be verified later against the listed task brief, handoffs, and docs.
- GitCode `/api/v5` issue, label, milestone, PR, comment, and file-content routes are treated as candidate public API surfaces until validated by design/research stages.
- Browser-session cookies and browser-derived tokens remain out of scope for MCP credential storage unless a later explicit product decision changes that.
- The iteration can use sanitized live-shaped fixtures and stubbed external GitCode responses to prove runtime behavior offline.
- If a surface is deferred, the target product must still expose clear diagnostics rather than silent success, empty results, or misleading transport/configuration errors.

## Runner Evidence
- Final message: `runa/calls/call-0006-run_request_formalization/attempt-1/final_message.txt`
