# Component Designs

This file is component navigation only. Use [Implementation Tasks](../implementation-tasks.md) for execution order.

- [CLI Startup](cli-startup.md) (`cli-startup`)
- [Credential Resolution](credential-resolution.md) (`credential-resolution`)
- [Repository Binding](repository-binding.md) (`repository-binding`)
- [Live Provider](live-provider.md) (`live-provider`)
- [Fixture Provider](fixture-provider.md) (`fixture-provider`)
- [Sync Service](sync-service.md) (`sync-service`)
- [Write Service](write-service.md) (`write-service`)
- [Cache Runtime](cache-runtime.md) (`cache-runtime`)
- [Audit Runtime](audit-runtime.md) (`audit-runtime`)
- [Doctor Readiness](doctor-readiness.md) (`doctor-readiness`)
- [Diagnostics](diagnostics.md) (`diagnostics`)
- [Mock GitCode API](mock-gitcode-api.md) (`mock-gitcode-api`)
- [CLI Integration Tests](cli-integration-tests.md) (`cli-integration-tests`)
