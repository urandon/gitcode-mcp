# Research Results

## Research Index
# Research Index

## Competitor Research
- GitHub CLI: `source document`
- go-keyring: `source document`
- Model Context Protocol: `source document`

## External Research

## Competitor Analysis

### Reference Study: GitHub CLI

GitHub CLI centralizes command startup through `ghcmd.Main`, a root Cobra command, and a shared factory that wires config, HTTP clients, auth, IO, repository resolution, and command constructors - evidence: `internal/ghcmd/cmd.go:57`, `internal/ghcmd/cmd.go:132`, `internal/ghcmd/cmd.go:175`, `pkg/cmd/root/root.go:64`.
Its key architectural choice is a live-by-default authenticated HTTP client whose token is resolved at request time from env/config/keyring and whose command code receives injected factory seams for tests - evidence: `pkg/cmd/factory/default.go:188`, `api/http_client.go:151`, `internal/config/config.go:234`, `pkg/cmd/issue/list/list.go:48`.
The strongest transferable idea is to make explicit hosted-provider mode observable by routing every live command through one injected factory/client/auth pipeline and proving behavior with offline HTTP transports or `httptest.Server` request counts - evidence: `pkg/httpmock/registry.go:18`, `pkg/httpmock/registry.go:83`, `pkg/cmd/api/api_test.go:1346`.

### Reference Study: go-keyring

go-keyring provides a small OS credential-store abstraction with platform providers hidden behind a common `Keyring` interface and package-level operations - `keyring.go:23`.
Its key architectural choice is a swappable package-level provider that platform `init()` installs and tests can replace with an in-memory mock - `keyring.go:7`, `keyring_mock.go:76`.
The strongest transferable idea is a credential-source seam that can be switched to a deterministic memory-backed provider for CLI integration tests without touching the real OS Keychain - `keyring_mock.go:76`.

### Reference Study: Model Context Protocol

Model Context Protocol reports connected-client readiness through explicit protocol/version/capability/identity exchange rather than by implying readiness from transport availability alone.
The key architectural choice is a narrow core plus optional components: base protocol, versioning, and message patterns are mandatory, while feature scopes are negotiated or omitted as needed.
The strongest transferable idea is for `doctor --live` to report effective provider mode, selected base URL, credential source, and a minimal connectivity/version context without adding unrelated MCP client features.

## External Research

# Executive Summary

- No external source candidates were retrieved, and live web search is explicitly disallowed for this stage.
- Because the provided component evidence is empty, this synthesis cannot make concrete source-backed external claims about GitCode APIs, Go CLI integration patterns, credential stores, provider wiring, cache/audit surfaces, or doctor/readiness formats.
- The strongest evidence-based finding is negative: the requested live-readiness iteration depends on provider-wiring, credential-injection, API-base-URL, and offline live-integration-test mechanisms that are not externally evidenced in the current bundle.
- Later design work should treat all concrete mechanisms as unresolved until repository evidence, official API documentation, sanitized captured fixtures, or approved external sources are available.

# Research Scope And Source Strategy

- Scope: external research synthesis for GitCode MCP live-readiness iteration 4, focused on Go-based CLI/startup provider wiring and offline mocked live validation.
- Search constraint: live web search was prohibited.
- Available evidence:
  - Curated source candidates: none.
  - Component evidence: empty object.
  - Component synthesis: negative findings only.
- Source strategy outcome: no external sources can be cited; therefore, this report avoids concrete external mechanism claims and instead records design-critical unknowns and evidence requirements.

# Relevant Existing External Mechanisms

No relevant external mechanisms can be source-backed from the current evidence bundle.

| Mechanism family | Evidence status | Consequence |
|---|---:|---|
| Go CLI integration testing through real startup path | No source evidence | Cannot claim a preferred harness shape beyond the request's own `httptest.Server` requirement. |
| Mock HTTP API validation | No source evidence | Cannot cite external precedent for request counting, auth failure simulation, or cache verification. |
| Credential source injection / Keychain-equivalent mock | No source evidence | Cannot assert a standard production/test credential abstraction. |
| API base URL precedence | No source evidence | Cannot compare repository-bound vs global URL authority using external references. |
| Idempotent write semantics | No source evidence | Cannot define header names, retry semantics, or response expectations. |
| Doctor/readiness JSON conventions | No source evidence | Cannot cite comparable CLI readiness schemas. |

# Design-Critical Unknowns

- Whether the target CLI can be invoked in-process from Go tests or requires a test binary wrapper.
- Whether live/offline provider selection is currently centralized or duplicated across commands.
- Whether credential resolution already has a production abstraction that can accept a test-only source.
- Whether `auth status`, `sync --live`, and `create-issue --live` share any credential pipeline.
- Which API base URL authority is currently documented, persisted, and consumed by the HTTP client.
- What GitCode-compatible request/response shapes are needed for issues, wiki pages, comments, and create-issue.
- How cache state and audit records can be inspected through runtime surfaces without relying on source-level assumptions.
- Whether fixture identifiers such as `ISSUE-42` and `WIKI-HOME` are stable test sentinels and where they originate.

# Architecture Alternatives And Trade-Offs

Because no external sources are available, the alternatives below are evidence-classified as inference from the request, not source-backed external findings.

| Concern | Alternative A | Alternative B | Trade-off / failure mode |
|---|---|---|---|
| Live provider construction | Central command startup builds provider once from effective config | Each command constructs or selects its own provider | Centralization reduces drift; per-command construction risks sync/write/auth divergence. |
| Credential injection | Shared resolver returns typed source/result consumed by auth, sync, write, provider | Commands read environment/keychain independently | Shared resolver supports parity tests; independent reads can reproduce the known auth-vs-write mismatch. |
| Missing credentials | Fail before provider HTTP client sends requests | Let provider attempt request without token | Preflight enables zero-request assertion; late failure can leak ambiguous live behavior. |
| Invalid token | Send request to mock/live provider and surface 401/403 | Fall back to fixtures or generic success | Provider reachability is proven only if mock server sees request. |
| API base URL authority | Repository binding controls per-repo live commands | Global config/env controls all live commands | Repo binding improves isolated testability; global config may be simpler but can conflict with per-repo expectations. |
| Offline default | Non-live commands stay fixture-backed | Non-live commands share live setup with disabled network | Fixture default preserves existing offline behavior; shared setup risks accidental network use. |

# Primary Decision Hierarchy

Evidence-supported hierarchy cannot be established. A later design stage should decide in this order:

1. Effective provider mode: live vs fixture/offline must be selected before service construction.
2. Credential resolution: typed credential result must be available before live provider construction and write gates.
3. API base URL authority: exactly one effective base URL must be selected before HTTP client construction.
4. Repository binding: live sync/write must bind to the intended repository identity before route construction.
5. Service route: sync/write services must receive the live provider, not fixture clients, when `--live` is explicit.
6. Observability: doctor/readiness must report the same effective mode, credential source, cache path, and base URL used by the live client.
7. Validation: offline integration tests must exercise the same command/startup path an operator uses.

# Low-Level Implementation Details

No low-level implementation details are source-backed in the current bundle. The following are acceptance-derived validation needs rather than external claims:

- A test-only GitCode-compatible HTTP server should expose minimal sanitized endpoints for:
  - issue listing;
  - wiki/page listing or fetch;
  - comment listing;
  - issue creation;
  - auth failure responses for invalid tokens.
- Tests should count requests by endpoint and token class to distinguish:
  - missing credential: zero requests;
  - invalid credential: at least one authenticated request with 401/403;
  - valid credential: successful sync/write route.
- Fixture fallback detection should assert absence of known fixture sentinels such as `ISSUE-42` and `WIKI-HOME` in live-mode cache/results.
- Credential parity should be tested by making `auth status` and `create-issue --live` consume the same mocked credential source while `GITCODE_TOKEN` is unset.
- Doctor/readiness should expose effective values, not merely configured values, for provider mode, credential source, cache path, and API base URL.

# Evidence Coverage

| Requested area | Direct evidence | Inference available | Status |
|---|---:|---:|---|
| CLI/startup live control flow | No | Yes, from request only | Evidence gap |
| Credential pipeline / Keychain-resolved token flow | No | Yes, from request only | Evidence gap |
| Mock GitCode API harness | No | Yes, from request only | Evidence gap |
| API base URL selection | No | Yes, from request only | Evidence gap |
| `create-issue --live` write path | No | Yes, from request only | Evidence gap |
| Sync path for issues/wiki/comments | No | Yes, from request only | Evidence gap |
| Doctor/readiness output | No | Yes, from request only | Evidence gap |
| Existing fixture fallback behavior | No | Yes, from request only | Evidence gap |

# Evidence Gaps And Negative Findings

- No official GitCode API documentation was provided.
- No sanitized GitCode compatibility fixtures were provided.
- No external Go CLI testing references were provided.
- No external credential-resolution or Keychain abstraction references were provided.
- No external idempotent-write guidance was provided.
- No external readiness/doctor JSON schema precedents were provided.
- No target repository inspection was allowed, so no local implementation claims can be made.
- No source-backed evidence confirms that existing `--live` flags, provider interfaces, cache layouts, audit records, or command names exist exactly as described.

# Findings By Component Or Concern

## Provider Wiring

- Direct evidence: none.
- Negative finding: no evidence identifies the startup seam where live provider construction should occur.
- Design risk: explicit `--live` can appear enabled while downstream services still receive a fixture-backed client.

## Credential Injection

- Direct evidence: none.
- Negative finding: no evidence proves a shared credential resolver spans auth status, sync, write checks, and live provider construction.
- Design risk: auth status can report a credential while live write fails or uses a different path.

## API Base URL Selection

- Direct evidence: none.
- Negative finding: no evidence establishes whether repository binding or global configuration is authoritative.
- Design risk: tests may configure one URL while the actual HTTP client uses another.

## Offline Live Integration Tests

- Direct evidence: none.
- Negative finding: no evidence confirms a current real-CLI test seam.
- Design risk: service-level mocks can pass while operator-facing CLI startup remains miswired.

## Sync And Write Services

- Direct evidence: none.
- Negative finding: no evidence identifies service route boundaries, audit persistence, cache refresh behavior, or idempotency semantics.
- Design risk: live provider reachability may not imply cache/audit correctness.

## Doctor / Readiness

- Direct evidence: none.
- Negative finding: no evidence defines current doctor output fields or whether it reports effective runtime values.
- Design risk: readiness output can report intended configuration rather than the provider actually used.

# Comparative External Systems

No comparative external systems can be cited from the current evidence bundle. Any comparison to GitHub CLI, Kubernetes health checks, Terraform providers, Docker credential helpers, or Go testing packages would require external sources that were not provided and cannot be fetched under the rules.

# Engineering Implications For Later Design

- Treat this research bundle as a constraint report, not a source-backed architecture recommendation.
- Require later stages to obtain one of the following before making concrete external claims:
  - repository-local evidence from allowed inspection;
  - official GitCode API documentation;
  - sanitized captured GitCode fixtures;
  - approved external references for Go CLI integration testing, credential abstraction, or readiness reporting.
- Prioritize tests that distinguish provider reachability from successful fixture fallback.
- Ensure every operator-visible live command consumes the same effective provider configuration path.
- Make missing-credential and invalid-token outcomes intentionally different:
  - missing credential: typed local failure and zero HTTP requests;
  - invalid token: live provider request observed and 401/403 surfaced.

# Follow-Up Questions For Later Design

1. What is the exact CLI entrypoint function or binary wrapper available to Go tests?
2. Where are live/offline provider modes currently selected?
3. What credential resolver does `auth status` use, and can it be injected in tests?
4. Which configuration field currently reaches the live HTTP client: repository `api_base_url`, global config, environment variable, or a hard-coded default?
5. What are the minimal sanitized GitCode-compatible routes and payloads needed for sync and create issue?
6. What cache/audit APIs can tests use to verify runtime state?
7. Are fixture identifiers `ISSUE-42` and `WIKI-HOME` guaranteed stable sentinels?
8. What exit codes and typed diagnostic structures are expected for missing credentials and auth failures?
9. How should idempotency be represented for issue creation: header, body field, persisted request key, or service-layer deduplication?
10. What exact JSON fields should `doctor --live --format json` expose as effective runtime values?

# Source Quality Notes

- Source count: zero.
- Citation status: no citations are used because no source records exist.
- Authority level: insufficient for concrete external claims.
- Freshness risk: not assessable.
- Implementation value: limited to identifying evidence gaps and acceptance-derived validation needs.

## Runner Evidence
- Final message: `runa/calls/call-0044-run_external_research/attempt-1/final_message.txt`
