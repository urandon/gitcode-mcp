# Request Formalization Revision 1

## Main user request information
Design GitCode MCP live-readiness iteration 4 as a narrow provider-wiring gap-closure plan for the Go target repository. The request focuses on making explicit `--live` CLI paths trustworthy through the same startup path operators use, with offline proof via a mocked GitCode-compatible HTTP server. Scope includes CLI live mode, provider construction, credential injection, repository binding, API base URL selection, sync/write service routes, audit/cache confirmation, and doctor/readiness reporting. Constraints: no broad rewrite, no target repository inspection in this stage, no real credentials/network/OS Keychain dependency for primary validation, public-safe sanitized fixtures only, and prior design package archives remain untouched.

## Decomposed tasks
### Task 1: Live startup provider wiring
Description: Define the CLI/startup path so explicit `--live` constructs the live provider and cannot silently use fixture-backed behavior.
Acceptance Criteria: Operator triggers `gitcode-mcp sync --live` through the real CLI entrypoint against a mocked GitCode HTTP API; the CLI uses the live provider startup route, sends requests to the mock server when credentials are usable, and an offline CLI integration test fails if fixture records such as `ISSUE-42` or `WIKI-HOME` appear.

### Task 2: Missing credential diagnostics
Description: Define typed missing-credential behavior before any live HTTP request is attempted.
Acceptance Criteria: Operator triggers `gitcode-mcp sync --live` with no environment token and no mocked credential source; the CLI returns typed missing-credential diagnostics, exits with the expected failure status, leaves the mock server request count at zero, and this is proven by an offline CLI integration test.

### Task 3: Credential source injection
Description: Define a credential pipeline shared by auth status, sync, write checks, and live provider construction, including a mocked Keychain-equivalent source.
Acceptance Criteria: Operator triggers `gitcode-mcp create-issue --live` with `GITCODE_TOKEN` unset and a mocked Keychain-equivalent credential source configured for the CLI process; the write credential gate accepts the resolved token, the mock server receives the authenticated create request, and an offline CLI integration test fails if auth status can see the credential but live write cannot.

### Task 4: Invalid token live failure
Description: Define live auth-failure handling so invalid credentials prove the live provider was reached and do not fall back to fixtures.
Acceptance Criteria: Operator triggers `gitcode-mcp sync --live` with an invalid test token against a mock server returning 401 or 403; the CLI reports an auth failure from the live provider, records no fixture success, and the offline CLI integration test proves the mock server received the request.

### Task 5: Live sync cache population
Description: Define sync behavior for issues, wiki pages, and comments using sanitized mock GitCode responses through the real CLI live path.
Acceptance Criteria: Operator triggers `gitcode-mcp sync --live` with a valid test token against the mocked GitCode API; the CLI fetches mock issues/wiki/comments, writes them into the configured cache, excludes fixture identifiers `ISSUE-42` and `WIKI-HOME`, and an offline CLI integration test verifies cache state through the target app runtime.

### Task 6: Live create issue write path
Description: Define `create-issue --live` through provider write, idempotency, audit recording, and cache confirmation.
Acceptance Criteria: Operator triggers `gitcode-mcp create-issue --live` with a valid test token against the mocked GitCode API; the CLI sends a create request with the expected idempotency behavior, records audit/cache confirmation visible through the target cache or audit surface, never returns `fixture client is read-only`, and an offline CLI integration test verifies the runtime result.

### Task 7: Offline sync remains fixture-backed
Description: Define the non-live default so ordinary sync keeps its existing offline fixture-backed behavior and never contacts the live provider.
Acceptance Criteria: Operator triggers `gitcode-mcp sync` without `--live` while a mock server is available; the CLI completes through the fixture-backed offline path, the mock server receives zero requests, and a CLI integration test proves default behavior is unchanged.

### Task 8: API base URL rule
Description: Choose one explicit API base URL authority for live commands and define acceptance tests for that rule.
Acceptance Criteria: Operator configures the selected API base URL authority and triggers `gitcode-mcp sync --live`; the live HTTP client uses exactly that base URL, ignores non-authoritative alternatives according to the documented rule, and offline CLI integration tests prove request routing by mock server hit counts and failure of the non-selected endpoint.

### Task 9: Doctor live readiness output
Description: Define `doctor --live` output for effective provider mode, credential source, cache path, and API base URL.
Acceptance Criteria: Operator triggers `gitcode-mcp doctor --live --format json`; the CLI returns JSON showing effective live provider mode, credential source, cache path, and API base URL used by the live client, and an offline CLI test verifies the fields using sanitized temporary paths and mocked credentials.

### Task 10: Mock GitCode API harness
Description: Define the `httptest.Server` integration harness that exercises the real command/startup path without real network, credentials, or OS Keychain.
Acceptance Criteria: Developer runs `go test ./...`; offline CLI live integration tests start a mocked GitCode-compatible HTTP server, run real CLI command paths for sync/create/doctor, assert request counts and cache/audit outcomes, and pass without real credentials, external network, or OS Keychain access.

## Assumptions
- The real CLI entrypoint can be exercised from Go tests without shelling out to an installed binary, or a test binary wrapper can provide equivalent startup coverage.
- Existing cache and audit surfaces can be inspected by tests through public or internal target-runtime APIs without relying on source-level claims at this stage.
- A test-only credential source can be injected through configuration, environment, or dependency seam while preserving the production credential resolution contract.
- Repository binding with `api_base_url` is likely the preferred base URL authority because it supports per-repository tests, but final confirmation belongs to the architecture/component stage.
- Mock GitCode payloads will be sanitized and minimal while preserving the response shapes needed for sync and create issue behavior.
- Optional real live e2e remains outside primary acceptance and is credential-gated.

## Runner Evidence
- Final message: `runa/calls/call-0006-run_request_formalization/attempt-1/final_message.txt`
